#!/bin/bash
# 使用 cocotb + iverilog 进行高级验证

cd "$(dirname "$0")"
MODULE=tb_top TOPLEVEL=tb_top \
cocotb-run \
    -v ../reram/macros/reram_8x8/reram_8x8.v \
    -v ../reram/macros/adc_3bit/adc_3bit.v \
    -v rtl/top.v \
    -v rtl/reram_ctrl.v \
    -v rtl/wishbone_if.v \
    -v rtl/adc_interface.v \
    -v rtl/accumulator.v \
    -v rtl/fsm.v \
    testbench/cocotb_test.py
