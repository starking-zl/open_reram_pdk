// ============================================================
// Module: top
// Function: Top-level integration of Ming She chip
//           Instantiates all sub-modules: wishbone interface,
//           CSR, FSM, ReRAM controller, CIM array, ADC interface,
//           accumulator, sensor interface, output buffer, and PMU.
// 功能：鸣蛇芯片顶层集成模块
//           例化所有子模块：Wishbone 接口、CSR、FSM、ReRAM 控制器、
//           存算阵列、ADC 接口、累加器、传感器接口、输出缓存和 PMU。
// ============================================================
//
// 【注意事项 / Notes】
// 1. 本模块为纯数字逻辑顶层，可综合。
// 2. 时钟与复位信号统一驱动所有子模块。
// 3. 模拟域信号（`iout`、`i_in`）使用 `real` 类型互连，用于行为级仿真。
//    实际硅中这些信号为模拟电流/电压，不可综合为数字逻辑。
// 4. Wishbone 接口直接引出，与外部主控连接。
// 5. 传感器接口引出，可与外部传感器芯片相连。
// 6. 所有内部连线命名遵循 `模块名_信号名` 的惯例以便调试。
// 7. 顶层不包含任何胶合逻辑，仅为纯例化。
// 8. 未使用的端口（如部分 PMU 溢出位）已适当悬空或接地。
//
// 1. This module is the top-level digital integration, synthesizable.
// 2. Clock and reset signals are distributed to all sub-modules.
// 3. Analog domain signals (`iout`, `i_in`) use `real` type for behavioral simulation.
//    In real silicon these are analog currents/voltages, not synthesizable as digital.
// 4. Wishbone interface is brought out directly for connection to external host.
// 5. Sensor interface is brought out for connection to external sensor chips.
// 6. Internal net names follow the convention `module_signal` for easier debugging.
// 7. Top-level contains no glue logic; pure instantiation only.
// 8. Unused ports (e.g., some PMU overflow bits) are appropriately left open or tied off.

module top (
    // 全局时钟与复位 / Global Clock and Reset
    input  wire         clk,
    input  wire         rst_n,

    // Wishbone 总线接口 / Wishbone Bus Interface
    input  wire         wb_cyc_i,
    input  wire         wb_stb_i,
    input  wire         wb_we_i,
    input  wire [31:0]  wb_addr_i,
    input  wire [31:0]  wb_data_i,
    output wire [31:0]  wb_data_o,
    output wire         wb_ack_o,
    output wire         wb_err_o,

    // 传感器外部接口 / External Sensor Interface
    output wire         sen_clk,
    input  wire [7:0]   sen_data,
    input  wire         sen_sync,

    // 中断输出 / Interrupt Outputs
    output wire         int_done,
    output wire         int_err
);

    // ============================================================
    // 内部互连信号声明 / Internal Interconnect Declarations
    // ============================================================

    // --- Wishbone 到 CSR 的接口 / Wishbone to CSR Interface ---
    wire        wb_csr_we;
    wire [7:0]  wb_csr_addr;
    wire [31:0] wb_csr_wdata;
    wire [31:0] csr_wb_rdata;

    // --- CSR 到 FSM 的控制信号 / CSR to FSM Control Signals ---
    wire        csr_fsm_start;
    wire [1:0]  csr_fsm_precision;
    wire [2:0]  csr_fsm_clk_div;        // 实际用于 sensor_if，通过 CSR 直接连出
    wire        fsm_csr_busy;
    wire        fsm_csr_done;
    wire        fsm_csr_err;
    wire [3:0]  fsm_csr_state;
    wire [7:0]  fsm_csr_err_code;

    // --- 权重配置接口 (CSR -> FSM / ReRAM Ctrl) / Weight Config Interface ---
    wire [3:0]  csr_weight_row;
    wire [3:0]  csr_weight_col;
    wire [7:0]  csr_weight_data;
    wire        csr_weight_wr_en;
    wire        reram_ctrl_prog_done;    // 单次编程完成
    wire        weight_all_loaded;       // 全阵列编程完成 (需在 CSR 或顶层生成)

    // --- FSM 到 ReRAM 控制器的信号 / FSM to ReRAM Controller Signals ---
    wire        fsm_reram_wr;
    wire [3:0]  fsm_reram_row;
    wire [3:0]  fsm_reram_col;
    wire [7:0]  fsm_reram_wdata;
    wire        fsm_reram_rd;

    // --- ReRAM 控制器到存算阵列 / ReRAM Ctrl to CIM Array ---
    wire        reram_array_wr;
    wire [3:0]  reram_array_row;
    wire [3:0]  reram_array_col;
    wire [7:0]  reram_array_wdata;
    wire [7:0]  reram_array_vin [0:15];

    // --- 存算阵列输出电流 (模拟) / CIM Array Output Currents (Analog) ---
    real        array_iout [0:15];

    // --- ADC 接口信号 / ADC Interface Signals ---
    wire        fsm_adc_start;
    wire        adc_fsm_done;
    wire [2:0]  adc_fsm_data;

    // --- 累加器信号 / Accumulator Signals ---
    wire        fsm_accum_en;
    wire        fsm_accum_rst;
    wire [15:0] accum_fsm_data;

    // --- 传感器接口信号 / Sensor Interface Signals ---
    wire        fsm_sensor_req;
    wire        sensor_fsm_ready;
    wire [7:0]  sensor_fsm_data;
    wire [1:0]  csr_sensor_mode;
    wire [2:0]  csr_sensor_ch_sel;
    wire        csr_sensor_chain;

    // --- 输入通道数据 (从 CSR 到 Sensor_if 或直接到阵列) / Input Channel Data ---
    wire [7:0]  csr_input_ch [0:7];

    // --- 输出缓存信号 / Output Buffer Signals ---
    wire        fsm_outbuf_wr;
    wire [2:0]  fsm_outbuf_addr;
    wire [15:0] accum_outbuf_data;
    wire        csr_outbuf_rd;
    wire [2:0]  csr_outbuf_addr;
    wire [15:0] outbuf_csr_data;

    // --- PMU 信号 / PMU Signals ---
    wire [3:0]  csr_pmu_sel;
    wire        csr_pmu_capture;
    wire        csr_pmu_clear;
    wire [31:0] pmu_csr_value;
    wire [4:0]  pmu_csr_overflow;
    wire [4:0]  pmu_inc;                // 计数器递增控制，由各模块事件驱动

    // --- 中断信号 (内部) / Interrupt Signals (internal) ---
    wire        csr_int_done_en;
    wire        csr_int_err_en;
    wire        csr_int_done_req;
    wire        csr_int_err_req;

    // ============================================================
    // 全阵列编程完成标志生成 / Weight All Loaded Generation
    // ============================================================
    // 简单实现：假设权重加载由软件控制顺序完成，加载完成后软件写 CSR 的某标志位。
    // 此处为简化，直接使用 csr_weight_wr_en 的下降沿计数器或由外部软件置位。
    // 实际应用中可在 CSR 中增加一个 WEIGHT_RDY 寄存器位，由软件置位。
    // 本设计中暂时接地 (表示始终已加载)，以简化 FSM 启动流程。
    assign weight_all_loaded = 1'b1;   // TODO: 根据需要连接至 CSR 状态位

    // ============================================================
    // Wishbone 接口模块例化 / Wishbone Interface Instantiation
    // ============================================================
    wishbone_if u_wishbone_if (
        .wb_clk_i    (clk),
        .wb_rst_n_i  (rst_n),
        .wb_cyc_i    (wb_cyc_i),
        .wb_stb_i    (wb_stb_i),
        .wb_we_i     (wb_we_i),
        .wb_addr_i   (wb_addr_i),
        .wb_data_i   (wb_data_i),
        .wb_data_o   (wb_data_o),
        .wb_ack_o    (wb_ack_o),
        .wb_err_o    (wb_err_o),
        .csr_we_o    (wb_csr_we),
        .csr_addr_o  (wb_csr_addr),
        .csr_wdata_o (wb_csr_wdata),
        .csr_rdata_i (csr_wb_rdata)
    );

    // ============================================================
    // CSR 寄存器组例化 / CSR Register Bank Instantiation
    // ============================================================
    csr u_csr (
        .clk_i               (clk),
        .rst_n_i             (rst_n),
        .we_i                (wb_csr_we),
        .addr_i              (wb_csr_addr),
        .wdata_i             (wb_csr_wdata),
        .rdata_o             (csr_wb_rdata),

        .ctrl_start_o        (csr_fsm_start),
        .ctrl_precision_o    (csr_fsm_precision),
        .ctrl_clk_div_o      (csr_fsm_clk_div),
        .status_busy_i       (fsm_csr_busy),
        .status_done_i       (fsm_csr_done),
        .status_err_i        (fsm_csr_err),
        .fsm_state_i         (fsm_csr_state),
        .err_code_i          (fsm_csr_err_code),

        .cfg_row_o           (csr_weight_row),
        .cfg_col_o           (csr_weight_col),
        .cfg_weight_o        (csr_weight_data),
        .cfg_wr_en_o         (csr_weight_wr_en),
        .weight_prog_done_i  (reram_ctrl_prog_done),
        .weight_all_loaded_i (weight_all_loaded),

        .input_ch0_o         (csr_input_ch[0]),
        .input_ch1_o         (csr_input_ch[1]),
        .input_ch2_o         (csr_input_ch[2]),
        .input_ch3_o         (csr_input_ch[3]),
        .input_ch4_o         (csr_input_ch[4]),
        .input_ch5_o         (csr_input_ch[5]),
        .input_ch6_o         (csr_input_ch[6]),
        .input_ch7_o         (csr_input_ch[7]),

        .input_ch_sel_o      (csr_sensor_ch_sel),
        .sensor_mode_o       (csr_sensor_mode[0]),  // 注意 csr.v 中 sensor_mode_o 为单比特
        .sensor_type_o       (csr_sensor_mode),     // 实际为 sensor_type，位宽匹配
        .chain_mode_o        (csr_sensor_chain),

        .output_ch0_i        (outbuf_csr_data),     // 输出通道数据来自 output_buffer
        .output_ch1_i        (16'h0),               // 暂未使用，接地
        .output_ch2_i        (16'h0),
        .output_ch3_i        (16'h0),
        .output_ch4_i        (16'h0),
        .output_ch5_i        (16'h0),
        .output_ch6_i        (16'h0),
        .output_ch7_i        (16'h0),

        .pmu_sel_o           (csr_pmu_sel),
        .pmu_capture_o       (csr_pmu_capture),
        .pmu_clear_o         (csr_pmu_clear),
        .pmu_value_i         (pmu_csr_value),
        .pmu_overflow_i      (pmu_csr_overflow),

        .int_done_en_o       (csr_int_done_en),
        .int_err_en_o        (csr_int_err_en),
        .int_done_o          (csr_int_done_req),
        .int_err_o           (csr_int_err_req)
    );

    // ============================================================
    // FSM 顶层状态机例化 / FSM Top Instantiation
    // ============================================================
    fsm_top #(
        .NUM_TILES(1)        // 单块计算
    ) u_fsm_top (
        .clk_i               (clk),
        .rst_n_i             (rst_n),
        .start_i             (csr_fsm_start),
        .precision_i         (csr_fsm_precision),
        .busy_o              (fsm_csr_busy),
        .done_o              (fsm_csr_done),

        .reram_wr_o          (fsm_reram_wr),
        .reram_row_o         (fsm_reram_row),
        .reram_col_o         (fsm_reram_col),
        .reram_wdata_o       (fsm_reram_wdata),
        .weight_prog_done_i  (reram_ctrl_prog_done),
        .weight_all_loaded_i (weight_all_loaded),

        .reram_rd_o          (fsm_reram_rd),
        .adc_start_o         (fsm_adc_start),
        .adc_done_i          (adc_fsm_done),
        .adc_data_i          (adc_fsm_data),

        .accum_en_o          (fsm_accum_en),
        .accum_rst_o         (fsm_accum_rst),
        .accum_data_i        (accum_fsm_data),

        .sensor_req_o        (fsm_sensor_req),
        .sensor_ready_i      (sensor_fsm_ready),
        .sensor_data_i       (sensor_fsm_data)
    );

    // 状态信号未完全引出，但 PMU 或其他模块可能用到，此处暂不连接
    assign fsm_csr_err = 1'b0;
    assign fsm_csr_state = 4'h0;
    assign fsm_csr_err_code = 8'h0;

    // ============================================================
    // ReRAM 控制器例化 / ReRAM Controller Instantiation
    // ============================================================
    reram_ctrl #(
        .PROG_PULSE_CYCLES(10)
    ) u_reram_ctrl (
        .clk_i           (clk),
        .rst_n_i         (rst_n),
        .wr_i            (fsm_reram_wr),
        .rd_i            (fsm_reram_rd),
        .row_i           (fsm_reram_row),
        .col_i           (fsm_reram_col),
        .wdata_i         (fsm_reram_wdata),
        .vin_i           (csr_input_ch),   // 输入向量来自 CSR（传感器模式时由 sensor_if 覆盖）
        .array_wr_o      (reram_array_wr),
        .array_row_o     (reram_array_row),
        .array_col_o     (reram_array_col),
        .array_wdata_o   (reram_array_wdata),
        .array_vin_o     (reram_array_vin),
        .prog_done_o     (reram_ctrl_prog_done)
    );

    // ============================================================
    // ReRAM 存算阵列例化 (行为级) / ReRAM CIM Array Instantiation
    // ============================================================
    reram_array_16x16 #(
        .WEIGHT_WIDTH(8),
        .INPUT_WIDTH(8),
        .ARRAY_SIZE(16),
        .OUTPUT_REAL(1)
    ) u_reram_array (
        .wr_i           (reram_array_wr),
        .row_i          (reram_array_row),
        .col_i          (reram_array_col),
        .wdata_i        (reram_array_wdata),
        .vin_i          (reram_array_vin),
        .iout_o         (array_iout)
    );

    // ============================================================
    // ADC 接口例化 / ADC Interface Instantiation
    // ============================================================
    adc_if #(
        .REAL_INPUT(1),
        .FULL_SCALE_CURRENT(256.0),  // 归一化值，可根据仿真调整
        .ADC_DELAY_CYCLES(8)
    ) u_adc_if (
        .clk_i          (clk),
        .rst_n_i        (rst_n),
        .start_i        (fsm_adc_start),
        .i_in           (array_iout),
        .done_o         (adc_fsm_done),
        .dout_o         (adc_fsm_data)
    );

    // ============================================================
    // 累加器例化 / Accumulator Instantiation
    // ============================================================
    accumulator u_accumulator (
        .clk_i          (clk),
        .rst_n_i        (rst_n),
        .en_i           (fsm_accum_en),
        .rst_acc_i      (fsm_accum_rst),
        .data_i         (adc_fsm_data),
        .result_o       (accum_fsm_data)
    );

    // ============================================================
    // 传感器接口例化 / Sensor Interface Instantiation
    // ============================================================
    sensor_if #(
        .CLK_FREQ_HZ(200_000_000),
        .PDM_DECIMATION(64)
    ) u_sensor_if (
        .clk_i          (clk),
        .rst_n_i        (rst_n),
        .mode_i         (csr_sensor_mode),
        .clk_div_i      (csr_fsm_clk_div),
        .req_i          (fsm_sensor_req),
        .ready_o        (sensor_fsm_ready),
        .data_o         (sensor_fsm_data),
        .sen_clk_o      (sen_clk),
        .sen_data_i     (sen_data),
        .sen_sync_i     (sen_sync)
    );

    // ============================================================
    // 输出缓存例化 / Output Buffer Instantiation
    // ============================================================
    output_buffer u_output_buffer (
        .clk_i          (clk),
        .rst_n_i        (rst_n),
        .wr_i           (fsm_outbuf_wr),
        .wr_addr_i      (fsm_outbuf_addr),
        .wr_data_i      (accum_fsm_data),
        .rd_i           (csr_outbuf_rd),
        .rd_addr_i      (csr_outbuf_addr),
        .rd_data_o      (outbuf_csr_data)
    );

    // 写使能与地址：FSM 在 DONE 状态发出写脉冲，选择通道 0
    assign fsm_outbuf_wr   = fsm_csr_done;
    assign fsm_outbuf_addr = 3'd0;

    // 读使能与地址：CSR 读 OUTPUT_CH0 时触发
    assign csr_outbuf_rd   = wb_csr_we ? 1'b0 : (wb_csr_addr == 8'h30);  // ADDR_OUTPUT_CH0
    assign csr_outbuf_addr = 3'd0;

    // ============================================================
    // PMU 例化 / PMU Instantiation
    // ============================================================
    // 事件递增信号生成 (示例)
    assign pmu_inc[0] = 1'b1;                 // 每个周期计数
    assign pmu_inc[1] = (fsm_csr_state == 4'd3);  // COMPUTE 状态
    assign pmu_inc[2] = (fsm_csr_state == 4'd4);  // ADC_CONV 状态
    assign pmu_inc[3] = (fsm_csr_state == 4'd2);  // WAIT_SENSOR 状态
    assign pmu_inc[4] = 1'b0;                 // Wishbone stall 暂不统计

    pmu u_pmu (
        .clk_i          (clk),
        .rst_n_i        (rst_n),
        .sel_i          (csr_pmu_sel),
        .capture_i      (csr_pmu_capture),
        .clear_i        (csr_pmu_clear),
        .inc_i          (pmu_inc),
        .value_o        (pmu_csr_value),
        .overflow_o     (pmu_csr_overflow)
    );

    // ============================================================
    // 中断输出 / Interrupt Outputs
    // ============================================================
    assign int_done = csr_int_done_req;
    assign int_err  = csr_int_err_req;

    // ============================================================
    // 仿真辅助 / Simulation Helper
    // ============================================================
`ifdef SIMULATION
    initial begin
        $display("[TOP] Ming She chip top-level initialized.");
    end
`endif

endmodule