// ============================================================
// Module: reram_ctrl
// Function: ReRAM array read/write timing controller
//           Generates programming pulses for weight update and
//           routes input vectors to the CIM array.
// 功能：ReRAM 阵列读写时序控制器
//           为权重更新生成编程脉冲，并将输入向量路由至存算阵列。
// ============================================================
//
// 【注意事项 / Notes】
// 1. 本模块为行为级模型，用于功能仿真，可综合但需注意脉冲宽度参数。
// 2. 编程脉冲宽度由参数 `PROG_PULSE_CYCLES` 定义，默认 10 个周期。
//    实际 ReRAM 编程需要特定电压-时间曲线，此处简化为固定宽度高电平。
// 3. `wr_i` 输入脉冲由 FSM 给出，本模块在其上升沿启动内部编程状态机，
//    并在脉冲持续期间保持 `array_wr_o` 有效。
// 4. 读操作 (`rd_i`) 无延迟，直接将输入向量传递给阵列，输出电流由阵列模块计算。
// 5. 地址和数据信号在编程期间必须保持稳定，本模块在内部状态机运行期间锁存输入值。
// 6. 内部状态机使用 `prog_state` 管理：IDLE -> PULSE -> DONE。
//
// 1. This module is a behavioral model for functional simulation. It is synthesizable
//    but note pulse width parameter considerations.
// 2. Programming pulse width is defined by parameter `PROG_PULSE_CYCLES`, default 10 cycles.
//    Actual ReRAM programming requires specific voltage-time profiles; here it is
//    simplified to a fixed-width high level.
// 3. `wr_i` input pulse is provided by FSM. This module detects its rising edge to start
//    an internal programming state machine, holding `array_wr_o` active for the pulse duration.
// 4. Read operation (`rd_i`) has no delay; input vectors are passed directly to the array.
//    Output current is computed by the array module.
// 5. Address and data signals must remain stable during programming. This module latches
//    input values while the internal state machine is active.
// 6. Internal state machine uses `prog_state`: IDLE -> PULSE -> DONE.

module reram_ctrl #(
    parameter PROG_PULSE_CYCLES = 10     // 编程脉冲持续周期数 / Programming pulse duration in cycles
) (
    input  wire         clk_i,
    input  wire         rst_n_i,

    // 控制输入 (来自 FSM) / Control Inputs (from FSM)
    input  wire         wr_i,            // 写使能脉冲 / Write enable pulse
    input  wire         rd_i,            // 读使能 / Read enable
    input  wire [3:0]   row_i,           // 行地址 / Row address
    input  wire [3:0]   col_i,           // 列地址 / Column address
    input  wire [7:0]   wdata_i,         // 写数据（权重）/ Write data (weight)

    // 输入向量 (来自传感器接口或寄存器) / Input Vector (from sensor interface or registers)
    input  wire [7:0]   vin_i [0:15],    // 16 路 8-bit 输入 / 16 channels of 8-bit input

    // 到 ReRAM 阵列的信号 / Signals to ReRAM Array
    output reg          array_wr_o,      // 阵列写使能 / Array write enable
    output reg  [3:0]   array_row_o,     // 阵列行地址 / Array row address
    output reg  [3:0]   array_col_o,     // 阵列列地址 / Array column address
    output reg  [7:0]   array_wdata_o,   // 阵列写数据 / Array write data
    output reg  [7:0]   array_vin_o [0:15], // 阵列输入向量 / Array input vector

    // 状态反馈 (到 FSM) / Status Feedback (to FSM)
    output reg          prog_done_o      // 单次编程完成脉冲 / Single programming done pulse
);

    // ============================================================
    // 编程状态机状态编码 / Programming FSM State Encoding
    // ============================================================
    localparam PROG_IDLE  = 2'd0,
               PROG_PULSE = 2'd1,
               PROG_DONE  = 2'd2;

    reg [1:0] prog_state, next_prog_state;
    reg [7:0] pulse_cnt;                 // 脉冲宽度计数器

    // 锁存的地址和数据 (在编程期间保持不变)
    reg [3:0] latched_row;
    reg [3:0] latched_col;
    reg [7:0] latched_wdata;

    // ============================================================
    // 编程状态机：状态寄存器 / Programming FSM: State Register
    // ============================================================
    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i)
            prog_state <= PROG_IDLE;
        else
            prog_state <= next_prog_state;
    end

    // ============================================================
    // 编程状态机：下一状态逻辑 / Programming FSM: Next State Logic
    // ============================================================
    always @(*) begin
        next_prog_state = prog_state;
        case (prog_state)
            PROG_IDLE: begin
                if (wr_i)
                    next_prog_state = PROG_PULSE;
            end

            PROG_PULSE: begin
                if (pulse_cnt >= PROG_PULSE_CYCLES - 1)
                    next_prog_state = PROG_DONE;
            end

            PROG_DONE: begin
                next_prog_state = PROG_IDLE;
            end
        endcase
    end

    // ============================================================
    // 编程状态机：输出逻辑与计数器 / Programming FSM: Output Logic & Counters
    // ============================================================
    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i) begin
            array_wr_o    <= 1'b0;
            array_row_o   <= 4'h0;
            array_col_o   <= 4'h0;
            array_wdata_o <= 8'h00;
            prog_done_o   <= 1'b0;
            pulse_cnt     <= 8'h0;
            latched_row   <= 4'h0;
            latched_col   <= 4'h0;
            latched_wdata <= 8'h00;
        end else begin
            // 默认值
            array_wr_o  <= 1'b0;
            prog_done_o <= 1'b0;

            case (prog_state)
                PROG_IDLE: begin
                    pulse_cnt <= 8'h0;
                    if (wr_i) begin
                        // 锁存输入地址和数据
                        latched_row   <= row_i;
                        latched_col   <= col_i;
                        latched_wdata <= wdata_i;
                    end
                end

                PROG_PULSE: begin
                    // 输出编程脉冲
                    array_wr_o    <= 1'b1;
                    array_row_o   <= latched_row;
                    array_col_o   <= latched_col;
                    array_wdata_o <= latched_wdata;
                    pulse_cnt     <= pulse_cnt + 1;
                end

                PROG_DONE: begin
                    // 脉冲结束，给出完成脉冲
                    prog_done_o <= 1'b1;
                end
            endcase
        end
    end

    // ============================================================
    // 读操作与输入向量路由 / Read Operation & Input Vector Routing
    // ============================================================
    integer i;
    always @(*) begin
        // 当 rd_i 有效时，将外部输入向量传递至阵列
        // 否则输出全 0（避免无效功耗，实际硅中可门控）
        if (rd_i) begin
            for (i = 0; i < 16; i = i + 1) begin
                array_vin_o[i] = vin_i[i];
            end
        end else begin
            for (i = 0; i < 16; i = i + 1) begin
                array_vin_o[i] = 8'h00;
            end
        end
    end

    // ============================================================
    // 仿真辅助：显示编程状态 / Simulation Helper: Display Programming State
    // ============================================================
`ifdef SIMULATION
    always @(posedge clk_i) begin
        if (prog_state == PROG_PULSE && pulse_cnt == 0)
            $display("[ReRAM_CTRL] Programming row=%d, col=%d, weight=%d", latched_row, latched_col, latched_wdata);
        if (prog_done_o)
            $display("[ReRAM_CTRL] Programming done");
    end
`endif

endmodule