// ============================================================
// Module: pmu
// Function: Performance Monitoring Unit for Ming She chip
//           Counts various hardware events to measure utilization,
//           throughput, and bottlenecks.
// 功能：鸣蛇芯片性能监控单元
//           统计多种硬件事件，用于测量利用率、吞吐率和瓶颈。
// ============================================================
//
// 【注意事项 / Notes】
// 1. 本模块为纯数字逻辑，可综合。
// 2. 内部包含 5 个 32 位计数器，分别统计：
//    - 0: 总周期数 (cycle_cnt)
//    - 1: 计算周期数 (comp_cnt) —— FSM 处于 COMPUTE 状态时计数
//    - 2: ADC 等待周期数 (adc_wait_cnt) —— FSM 处于 ADC_CONV 状态时计数
//    - 3: 传感器等待周期数 (sensor_wait_cnt) —— FSM 处于 WAIT_SENSOR 状态时计数
//    - 4: Wishbone 阻塞周期数 (wb_stall_cnt) —— Wishbone 访问等待时计数
// 3. 计数器由 `inc_i` 总线控制递增，每个位对应一个计数器。
// 4. 通过 `sel_i` 选择要读取或清零的计数器。
// 5. `capture_i` 有效时，所选计数器的值被捕获到 `value_o`，用于 CSR 读取。
// 6. `clear_i` 有效时，所选计数器清零。
// 7. 溢出标志 `overflow_o` 为各计数器最高位溢出时置位，保持直到清零。
// 8. 所有计数器在复位后清零。
//
// 1. This module is pure digital logic and synthesizable.
// 2. Contains five 32-bit counters counting:
//    - 0: Total cycles (cycle_cnt)
//    - 1: Compute cycles (comp_cnt) —— when FSM is in COMPUTE state
//    - 2: ADC wait cycles (adc_wait_cnt) —— when FSM is in ADC_CONV state
//    - 3: Sensor wait cycles (sensor_wait_cnt) —— when FSM is in WAIT_SENSOR state
//    - 4: Wishbone stall cycles (wb_stall_cnt) —— when Wishbone access waits
// 3. Counters are incremented by the `inc_i` bus; each bit corresponds to one counter.
// 4. `sel_i` selects which counter to read or clear.
// 5. When `capture_i` is asserted, the selected counter value is captured to `value_o`.
// 6. When `clear_i` is asserted, the selected counter is cleared.
// 7. Overflow flags `overflow_o` are set when a counter MSB overflows; they remain set until cleared.
// 8. All counters are cleared on reset.

module pmu (
    input  wire         clk_i,
    input  wire         rst_n_i,

    // 控制接口 (来自 CSR) / Control Interface (from CSR)
    input  wire [3:0]   sel_i,          // 计数器选择 (0-4) / Counter select
    input  wire         capture_i,      // 捕获计数值 / Capture counter value
    input  wire         clear_i,        // 清零所选计数器 / Clear selected counter

    // 计数器递增控制 (来自各模块事件) / Counter Increment Control (from various modules)
    input  wire [4:0]   inc_i,          // 每个位对应一个计数器的递增使能 / One bit per counter increment enable

    // 状态输出 (到 CSR) / Status Outputs (to CSR)
    output reg  [31:0]  value_o,        // 所选计数器的当前值 / Current value of selected counter
    output reg  [4:0]   overflow_o      // 各计数器溢出标志 / Overflow flags per counter
);

    // ============================================================
    // 计数器索引定义 / Counter Index Definitions
    // ============================================================
    localparam CNT_CYCLE   = 0,
               CNT_COMP    = 1,
               CNT_ADC     = 2,
               CNT_SENSOR  = 3,
               CNT_WB      = 4,
               NUM_CNT     = 5;

    // ============================================================
    // 计数器寄存器组 / Counter Register File
    // ============================================================
    reg [31:0] counters [0:NUM_CNT-1];
    reg [NUM_CNT-1:0] overflow_reg;

    // ============================================================
    // 计数器递增与溢出检测 / Counter Increment and Overflow Detection
    // ============================================================
    integer i;
    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i) begin
            for (i = 0; i < NUM_CNT; i = i + 1) begin
                counters[i] <= 32'h0;
            end
            overflow_reg <= {NUM_CNT{1'b0}};
        end else begin
            // 清零操作
            if (clear_i && (sel_i < NUM_CNT)) begin
                counters[sel_i] <= 32'h0;
                overflow_reg[sel_i] <= 1'b0;
            end

            // 递增操作
            for (i = 0; i < NUM_CNT; i = i + 1) begin
                if (inc_i[i]) begin
                    {overflow_reg[i], counters[i]} <= counters[i] + 1;
                end
            end
        end
    end

    // ============================================================
    // 捕获逻辑 / Capture Logic
    // ============================================================
    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i) begin
            value_o <= 32'h0;
        end else begin
            if (capture_i && (sel_i < NUM_CNT)) begin
                value_o <= counters[sel_i];
            end
        end
    end

    // ============================================================
    // 溢出标志输出 / Overflow Flag Output
    // ============================================================
    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i) begin
            overflow_o <= 5'h0;
        end else begin
            overflow_o <= overflow_reg;
        end
    end

    // ============================================================
    // 仿真辅助 / Simulation Helper
    // ============================================================
`ifdef SIMULATION
    always @(posedge clk_i) begin
        if (clear_i)
            $display("[PMU] Clear counter %d", sel_i);
        if (capture_i)
            $display("[PMU] Capture counter %d: value=0x%08h", sel_i, counters[sel_i]);
    end
`endif

endmodule