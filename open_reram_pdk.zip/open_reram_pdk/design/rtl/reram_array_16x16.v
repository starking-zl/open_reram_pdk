// ============================================================
// Module: reram_array_16x16
// Function: 16x16 ReRAM Compute-In-Memory array (behavioral model)
//           Performs analog matrix-vector multiplication:
//           iout = weights * vin (current sum per column)
// 功能：16x16 ReRAM 存算一体阵列（行为级模型）
//           执行模拟矩阵-向量乘法：iout = 权重矩阵 × 输入向量
//           输出为每列的模拟电流和（仿真中用实数表示）
// ============================================================
//
// 【注意事项 / Notes】
// 1. 本模块为行为级模型，仅用于功能仿真和架构探索，不可综合为实际硅电路。
// 2. 输出端口 `iout_o` 使用 SystemVerilog `real` 类型模拟模拟域电流和。
//    部分老旧仿真器可能不支持 `real` 端口数组，此时可将 OUTPUT_REAL 参数设为 0，
//    并修改输出为定点数（需自行修改代码）。
// 3. 权重编程通过 `wr_i` 上升沿触发，实际 ReRAM 编程需要纳秒级高压脉冲序列，
//    此处简化为单周期寄存器写入。
// 4. 矩阵乘法为全组合逻辑，延迟取决于仿真器优化，实际硅中延迟由导线 RC 决定。
// 5. 所有权重在上电后由 initial 块初始化为 0，该语句在综合时将被忽略。
//
// 1. This module is a behavioral model intended for functional simulation and
//    architectural exploration only. It is NOT synthesizable to actual silicon.
// 2. Output `iout_o` uses SystemVerilog `real` type to emulate analog current sums.
//    Some older simulators may not support arrays of `real` ports. In such cases,
//    set parameter OUTPUT_REAL=0 and modify output to fixed-point (requires manual edit).
// 3. Weight programming is triggered by the rising edge of `wr_i`. Actual ReRAM
//    programming requires nanosecond-scale high-voltage pulse trains; here it is
//    simplified to a single-cycle register write.
// 4. Matrix multiplication is purely combinational; delay depends on simulator
//    optimization. In real silicon, delay is dominated by wire RC.
// 5. All weights are initialized to 0 by an initial block at power-up. This statement
//    is ignored during synthesis.

module reram_array_16x16 #(
    parameter WEIGHT_WIDTH = 8,          // 权重位宽 / Weight bit-width
    parameter INPUT_WIDTH  = 8,          // 输入位宽 / Input bit-width
    parameter ARRAY_SIZE   = 16,         // 阵列尺寸 / Array dimension
    parameter OUTPUT_REAL  = 1           // 1 = 使用 real 类型输出电流 / Use real for current output
) (
    // 权重编程接口 / Weight Programming Interface
    input  wire                     wr_i,        // 写使能 / Write enable
    input  wire [3:0]               row_i,       // 行地址 (0-15) / Row address
    input  wire [3:0]               col_i,       // 列地址 (0-15) / Column address
    input  wire [WEIGHT_WIDTH-1:0]  wdata_i,     // 权重数据 / Weight data

    // 输入向量接口 / Input Vector Interface
    input  wire [INPUT_WIDTH-1:0]   vin_i [0:ARRAY_SIZE-1], // 8路输入（数字表示模拟电压）

    // 模拟电流输出 / Analog Current Output
    output real                     iout_o [0:ARRAY_SIZE-1]
);

    // ============================================================
    // 权重存储阵列 (16x16 寄存器组)
    // Weight storage array (16x16 register file)
    // ============================================================
    reg signed [WEIGHT_WIDTH-1:0] weight_array [0:ARRAY_SIZE-1][0:ARRAY_SIZE-1];

    // ============================================================
    // 权重编程逻辑 / Weight Programming Logic
    // ============================================================
    integer i, j;
    always @(posedge wr_i) begin
        // 将权重写入指定行列
        // Write weight to specified row and column
        weight_array[row_i][col_i] <= wdata_i;
    end

    // ============================================================
    // 模拟矩阵-向量乘法 / Analog Matrix-Vector Multiplication
    // iout[col] = sum_{row=0}^{15} (weight[row][col] * vin[row])
    // ============================================================
    generate
        genvar col_idx;
        for (col_idx = 0; col_idx < ARRAY_SIZE; col_idx = col_idx + 1) begin : col_loop
            always @(*) begin
                real sum;
                integer row_idx;
                sum = 0.0;
                for (row_idx = 0; row_idx < ARRAY_SIZE; row_idx = row_idx + 1) begin
                    // 将数字量转换为归一化电流贡献：权重 × 输入
                    // Convert digital values to normalized current contribution
                    sum = sum + $itor(weight_array[row_idx][col_idx]) * $itor(vin_i[row_idx]);
                end
                iout_o[col_idx] = sum;
            end
        end
    endgenerate

    // ============================================================
    // 初始化：所有权重清零 (仅仿真生效)
    // Initialization: All weights set to zero (simulation only)
    // ============================================================
    initial begin
        for (i = 0; i < ARRAY_SIZE; i = i + 1) begin
            for (j = 0; j < ARRAY_SIZE; j = j + 1) begin
                weight_array[i][j] = 0;
            end
        end
    end

endmodule