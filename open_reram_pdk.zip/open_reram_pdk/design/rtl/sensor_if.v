// ============================================================
// Module: sensor_if
// Function: Multi-mode sensor parallel interface for Ming She chip
//           Supports PDM, I2S, and parallel ADC sensor protocols.
//           Provides clock output, receives sensor data, and outputs
//           formatted data to the CIM array input channels.
// 功能：鸣蛇芯片多模式传感器并行接口
//           支持 PDM、I2S 和并行 ADC 传感器协议。
//           提供时钟输出，接收传感器数据，并将格式化后的数据输出
//           至存算阵列输入通道。
// ============================================================
//
// 【注意事项 / Notes】
// 1. 本模块为行为级模型，用于功能仿真，可综合但需根据具体传感器调整时序参数。
// 2. 支持三种传感器模式，由 `mode_i` 选择：
//    - 2'b00: PDM (脉冲密度调制) 麦克风
//    - 2'b01: I2S (音频接口)
//    - 2'b10: 并行 ADC (通用 8-bit 并行数据)
//    - 2'b11: 保留 / Reserved
// 3. 传感器时钟 `sen_clk_o` 由系统时钟分频得到，分频系数由 `clk_div_i` 控制。
// 4. 数据请求由 FSM 通过 `req_i` 脉冲发起，模块在数据就绪后置 `ready_o` 并输出 `data_o`。
// 5. PDM 模式下，输入为单比特流，内部需进行抽取滤波（此处简化为计数器累加）。
// 6. I2S 模式下，假设数据为立体声 16-bit，此处仅截取左声道高 8 位作为单通道输出。
// 7. 并行 ADC 模式下，直接透传 `sen_data_i`。
// 8. 若需多通道同步采集，请结合 `chain_mode_i` 在顶层轮询多个传感器接口实例。
// 9. 所有时序均基于系统时钟 `clk_i`，传感器时钟边沿对齐由内部状态机处理。
//
// 1. This module is a behavioral model for functional simulation. It is synthesizable
//    but timing parameters may need adjustment for specific sensors.
// 2. Three sensor modes are supported, selected by `mode_i`:
//    - 2'b00: PDM (Pulse Density Modulation) microphone
//    - 2'b01: I2S (Inter-IC Sound)
//    - 2'b10: Parallel ADC (general 8-bit parallel)
//    - 2'b11: Reserved
// 3. Sensor clock `sen_clk_o` is derived from system clock via division, controlled by `clk_div_i`.
// 4. Data request is initiated by FSM via a pulse on `req_i`. When data is ready, the module
//    asserts `ready_o` and outputs `data_o`.
// 5. In PDM mode, input is a single-bit stream. Internal decimation filtering is required;
//    here simplified to a counter accumulator.
// 6. In I2S mode, stereo 16-bit data is assumed; only the upper 8 bits of the left channel
//    are extracted as a single-channel output.
// 7. In Parallel ADC mode, `sen_data_i` is passed through directly.
// 8. For multi-channel synchronized acquisition, combine with `chain_mode_i` and instantiate
//    multiple sensor interfaces at the top level.
// 9. All timing is based on system clock `clk_i`. Sensor clock edge alignment is handled
//    by internal state machines.

module sensor_if #(
    parameter CLK_FREQ_HZ   = 200_000_000, // 系统时钟频率 / System clock frequency (200 MHz)
    parameter PDM_DECIMATION = 64           // PDM 抽取因子 / PDM decimation factor
) (
    input  wire         clk_i,
    input  wire         rst_n_i,

    // 控制接口 (来自 CSR) / Control Interface (from CSR)
    input  wire [1:0]   mode_i,         // 传感器模式 / Sensor mode
    input  wire [2:0]   clk_div_i,      // 时钟分频系数 / Clock divider (0=bypass, 1=div2, ..., 7=div8)

    // FSM 交互接口 / FSM Interaction Interface
    input  wire         req_i,          // 请求数据脉冲 / Request data pulse
    output reg          ready_o,        // 数据有效标志 / Data ready flag
    output reg  [7:0]   data_o,         // 输出数据 (到存算阵列) / Output data (to CIM array)

    // 外部传感器接口 / External Sensor Interface
    output reg          sen_clk_o,      // 传感器时钟输出 / Sensor clock output
    input  wire [7:0]   sen_data_i,     // 传感器数据输入 / Sensor data input
    input  wire         sen_sync_i      // 帧同步/字对齐信号 (用于 I2S) / Frame sync/word align
);

    // ============================================================
    // 模式编码 / Mode Encoding
    // ============================================================
    localparam MODE_PDM     = 2'b00,
               MODE_I2S     = 2'b01,
               MODE_PARALLEL = 2'b10;

    // ============================================================
    // 内部信号 / Internal Signals
    // ============================================================
    reg [7:0]  clk_div_cnt;        // 时钟分频计数器
    reg        sen_clk_int;        // 内部传感器时钟
    reg        req_latched;        // 请求锁存
    reg        busy;              // 采集忙标志

    // PDM 模式专用
    reg [15:0] pdm_acc;           // PDM 累加器
    reg [7:0]  pdm_bit_cnt;       // PDM 位计数器
    reg        pdm_data_rdy;      // PDM 数据就绪

    // I2S 模式专用
    reg [4:0]  i2s_bit_cnt;       // I2S 位计数器 (0-31)
    reg [31:0] i2s_shift_reg;     // I2S 移位寄存器
    reg        i2s_word_rdy;      // I2S 字就绪
    reg        i2s_ws;            // I2S 字选通 (左右声道)

    // 并行模式专用
    reg        parallel_rdy;      // 并行数据就绪

    // ============================================================
    // 传感器时钟生成 / Sensor Clock Generation
    // ============================================================
    wire [7:0] div_factor;
    assign div_factor = {5'b0, clk_div_i} + 1;  // 分频系数 = clk_div_i + 1

    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i) begin
            clk_div_cnt <= 8'h0;
            sen_clk_int <= 1'b0;
        end else begin
            if (clk_div_cnt >= (div_factor >> 1) - 1) begin
                clk_div_cnt <= 8'h0;
                sen_clk_int <= ~sen_clk_int;
            end else begin
                clk_div_cnt <= clk_div_cnt + 1;
            end
        end
    end
    assign sen_clk_o = sen_clk_int;

    // ============================================================
    // 主状态机与数据采集 / Main FSM and Data Acquisition
    // ============================================================
    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i) begin
            ready_o      <= 1'b0;
            data_o       <= 8'h00;
            req_latched  <= 1'b0;
            busy         <= 1'b0;

            // PDM
            pdm_acc      <= 16'h0;
            pdm_bit_cnt  <= 8'h0;
            pdm_data_rdy <= 1'b0;

            // I2S
            i2s_bit_cnt  <= 5'h0;
            i2s_shift_reg<= 32'h0;
            i2s_word_rdy <= 1'b0;
            i2s_ws       <= 1'b0;

            // Parallel
            parallel_rdy <= 1'b0;
        end else begin
            // 默认值
            ready_o <= 1'b0;

            // 请求锁存
            if (req_i && !busy) begin
                req_latched <= 1'b1;
                busy        <= 1'b1;
            end

            // 根据不同模式处理数据采集
            case (mode_i)
                MODE_PDM: begin
                    // PDM 模式：在 sen_clk_int 上升沿采样数据位
                    if (req_latched) begin
                        // 每次时钟上升沿累加一个位
                        if (sen_clk_int && !sen_clk_o) begin  // 上升沿检测 (简化)
                            pdm_acc <= pdm_acc + {15'h0, sen_data_i[0]};
                            pdm_bit_cnt <= pdm_bit_cnt + 1;
                            if (pdm_bit_cnt == PDM_DECIMATION - 1) begin
                                // 抽取完成，输出平均值的高 8 位
                                data_o <= pdm_acc[15:8];
                                pdm_data_rdy <= 1'b1;
                                pdm_bit_cnt <= 8'h0;
                                pdm_acc <= 16'h0;
                                req_latched <= 1'b0;
                                busy <= 1'b0;
                            end
                        end
                    end
                    if (pdm_data_rdy) begin
                        ready_o <= 1'b1;
                        pdm_data_rdy <= 1'b0;
                    end
                end

                MODE_I2S: begin
                    // I2S 模式：在 sen_clk_int 下降沿移位，上升沿锁存数据 (标准 I2S 时序简化)
                    if (req_latched) begin
                        // 用 sen_sync_i 作为字选通 (WS) 指示左右声道
                        // 这里简化：仅采集左声道 (WS=0) 的第一个 8 位数据
                        if (!sen_clk_int && sen_clk_o) begin  // 下降沿
                            i2s_shift_reg <= {i2s_shift_reg[30:0], sen_data_i[0]};
                            i2s_bit_cnt <= i2s_bit_cnt + 1;
                        end
                        if (sen_sync_i && !i2s_ws) begin  // WS 上升沿表示新字开始
                            i2s_ws <= 1'b1;
                        end else if (!sen_sync_i && i2s_ws) begin
                            i2s_ws <= 1'b0;
                            // 字结束，提取左声道数据 (假设左声道在 WS 高电平期间传输)
                            if (i2s_bit_cnt >= 8) begin
                                data_o <= i2s_shift_reg[31:24];  // 取最高 8 位
                                i2s_word_rdy <= 1'b1;
                                i2s_bit_cnt <= 5'h0;
                                i2s_shift_reg <= 32'h0;
                                req_latched <= 1'b0;
                                busy <= 1'b0;
                            end
                        end
                    end
                    if (i2s_word_rdy) begin
                        ready_o <= 1'b1;
                        i2s_word_rdy <= 1'b0;
                    end
                end

                MODE_PARALLEL: begin
                    // 并行 ADC 模式：直接采样
                    if (req_latched) begin
                        data_o <= sen_data_i;
                        parallel_rdy <= 1'b1;
                        req_latched <= 1'b0;
                        busy <= 1'b0;
                    end
                    if (parallel_rdy) begin
                        ready_o <= 1'b1;
                        parallel_rdy <= 1'b0;
                    end
                end

                default: begin
                    // 保留模式，不操作
                    req_latched <= 1'b0;
                    busy <= 1'b0;
                end
            endcase
        end
    end

    // ============================================================
    // 仿真辅助 / Simulation Helper
    // ============================================================
`ifdef SIMULATION
    always @(posedge clk_i) begin
        if (req_i)
            $display("[SENSOR] Request received, mode=%d", mode_i);
        if (ready_o)
            $display("[SENSOR] Data ready: 0x%02h", data_o);
    end
`endif

endmodule