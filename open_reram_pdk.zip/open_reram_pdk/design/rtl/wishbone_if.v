// ============================================================
// Module: wishbone_if
// Function: Wishbone B4 slave interface for Ming She chip
//           Handles register read/write access from external host.
//           Translates Wishbone bus transactions to internal CSR interface.
// 功能：鸣蛇芯片 Wishbone B4 从机接口
//           处理来自外部主机的寄存器读写访问。
//           将 Wishbone 总线事务转换为内部 CSR 接口信号。
// ============================================================
//
// 【注意事项 / Notes】
// 1. 本模块为纯数字逻辑，可综合。
// 2. 遵循 Wishbone B4 标准规范，支持单周期读写应答。
// 3. 地址总线宽度为 32 位，但实际仅使用低 8 位 (偏移地址 0x00–0xFF)。
//    访问超出范围的地址将返回错误并置 `wb_err_o`。
// 4. 写操作在 `wb_cyc_i` 和 `wb_stb_i` 同时有效且 `wb_we_i=1` 时执行。
// 5. 读操作在 `wb_cyc_i` 和 `wb_stb_i` 同时有效且 `wb_we_i=0` 时执行，
//    数据在下一周期通过 `wb_data_o` 返回，同时 `wb_ack_o` 置位。
// 6. 内部 CSR 接口信号为简化版：`csr_we_o` (写使能)、`csr_addr_o[7:0]`、
//    `csr_wdata_o[31:0]`、`csr_rdata_i[31:0]`。
// 7. 所有读写访问均为单周期完成，无等待状态插入。
// 8. 若访问未映射的地址空间，`wb_err_o` 会在应答周期置位。
//
// 1. This module is pure digital logic and synthesizable.
// 2. Complies with Wishbone B4 standard, supports single-cycle read/write.
// 3. Address bus is 32-bit wide, but only low 8 bits (offset 0x00–0xFF) are used.
//    Accesses beyond this range will assert `wb_err_o`.
// 4. Write transaction occurs when `wb_cyc_i` and `wb_stb_i` are both asserted
//    and `wb_we_i=1`.
// 5. Read transaction occurs when `wb_cyc_i` and `wb_stb_i` are both asserted
//    and `wb_we_i=0`. Data is returned on the next cycle via `wb_data_o`,
//    accompanied by `wb_ack_o`.
// 6. Internal CSR interface is simplified: `csr_we_o` (write enable),
//    `csr_addr_o[7:0]`, `csr_wdata_o[31:0]`, `csr_rdata_i[31:0]`.
// 7. All accesses complete in one cycle; no wait states are inserted.
// 8. Accesses to unmapped address space will cause `wb_err_o` to be asserted
//    during the acknowledge cycle.

module wishbone_if (
    // Wishbone 总线信号 / Wishbone Bus Signals
    input  wire         wb_clk_i,
    input  wire         wb_rst_n_i,
    input  wire         wb_cyc_i,
    input  wire         wb_stb_i,
    input  wire         wb_we_i,
    input  wire [31:0]  wb_addr_i,
    input  wire [31:0]  wb_data_i,
    output reg  [31:0]  wb_data_o,
    output reg          wb_ack_o,
    output reg          wb_err_o,

    // 内部 CSR 接口 / Internal CSR Interface
    output reg          csr_we_o,
    output reg  [7:0]   csr_addr_o,
    output reg  [31:0]  csr_wdata_o,
    input  wire [31:0]  csr_rdata_i
);

    // ============================================================
    // 地址有效范围检测 / Address Valid Range Detection
    // ============================================================
    wire addr_valid;
    assign addr_valid = (wb_addr_i[31:8] == 24'h000000);  // 高 24 位必须为 0

    // ============================================================
    // 总线访问状态机 / Bus Access State Machine
    // ============================================================
    localparam IDLE   = 2'b00,
               ACCESS = 2'b01,
               ACK    = 2'b10;

    reg [1:0] state, next_state;

    always @(posedge wb_clk_i or negedge wb_rst_n_i) begin
        if (!wb_rst_n_i)
            state <= IDLE;
        else
            state <= next_state;
    end

    always @(*) begin
        next_state = state;
        case (state)
            IDLE: begin
                if (wb_cyc_i && wb_stb_i)
                    next_state = ACCESS;
            end

            ACCESS: begin
                // 访问处理仅需一个周期，下一个周期进入 ACK 状态
                next_state = ACK;
            end

            ACK: begin
                // 应答后若无新请求则返回 IDLE
                if (!(wb_cyc_i && wb_stb_i))
                    next_state = IDLE;
                else
                    next_state = ACCESS;  // 连续访问
            end
        endcase
    end

    // ============================================================
    // 输出逻辑 / Output Logic
    // ============================================================
    always @(posedge wb_clk_i or negedge wb_rst_n_i) begin
        if (!wb_rst_n_i) begin
            wb_data_o    <= 32'h0;
            wb_ack_o     <= 1'b0;
            wb_err_o     <= 1'b0;
            csr_we_o     <= 1'b0;
            csr_addr_o   <= 8'h00;
            csr_wdata_o  <= 32'h0;
        end else begin
            // 默认值
            wb_ack_o     <= 1'b0;
            wb_err_o     <= 1'b0;
            csr_we_o     <= 1'b0;

            case (state)
                IDLE: begin
                    // 无操作
                end

                ACCESS: begin
                    if (wb_cyc_i && wb_stb_i) begin
                        // 检查地址是否有效
                        if (addr_valid) begin
                            if (wb_we_i) begin
                                // 写操作：向 CSR 发出写使能和地址、数据
                                csr_we_o    <= 1'b1;
                                csr_addr_o  <= wb_addr_i[7:0];
                                csr_wdata_o <= wb_data_i;
                            end else begin
                                // 读操作：向 CSR 发出地址，数据将在下一周期读取
                                csr_addr_o <= wb_addr_i[7:0];
                            end
                        end else begin
                            // 地址无效，将在 ACK 周期报错
                        end
                    end
                end

                ACK: begin
                    // 向主机返回应答
                    wb_ack_o <= 1'b1;
                    if (addr_valid) begin
                        if (!wb_we_i) begin
                            // 读操作：返回 CSR 读出的数据
                            wb_data_o <= csr_rdata_i;
                        end
                        wb_err_o <= 1'b0;
                    end else begin
                        // 地址无效，返回错误
                        wb_err_o <= 1'b1;
                        wb_data_o <= 32'hDEAD_BEEF;  // 错误标识
                    end
                end
            endcase
        end
    end

    // ============================================================
    // 仿真辅助：显示总线访问 / Simulation Helper: Display Bus Access
    // ============================================================
`ifdef SIMULATION
    always @(posedge wb_clk_i) begin
        if (state == ACK && wb_ack_o) begin
            if (wb_we_i)
                $display("[Wishbone] Write addr=0x%08h, data=0x%08h", wb_addr_i, wb_data_i);
            else
                $display("[Wishbone] Read  addr=0x%08h, data=0x%08h", wb_addr_i, wb_data_o);
        end
        if (state == ACK && wb_err_o)
            $display("[Wishbone] ERROR: Invalid address 0x%08h", wb_addr_i);
    end
`endif

endmodule