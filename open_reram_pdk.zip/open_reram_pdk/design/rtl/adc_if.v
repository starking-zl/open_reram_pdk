// ============================================================
// Module: adc_if
// Function: 3-bit Flash ADC behavioral model for current readout
//           Converts analog current sum from ReRAM array to digital code
// 功能：3-bit Flash ADC 行为模型，用于电流读出
//           将来自 ReRAM 阵列的模拟电流和转换为 3-bit 数字码
// ============================================================
//
// 【注意事项 / Notes】
// 1. 本模块为行为级模型，仅用于功能仿真和架构探索，不可综合。
// 2. 输入电流 `i_in` 为 SystemVerilog `real` 数组，部分仿真器可能不支持数组端口，
//    可改为 8 个独立 `real` 端口：`input real i_in0, i_in1, ...`。
// 3. 转换延迟 `ADC_DELAY_CYCLES` 默认 8 个周期，可根据需要调整。
// 4. 满量程电流 `FULL_SCALE_CURRENT` 为归一化值，需根据实际电压摆幅和跨阻增益设定。
// 5. 量化函数 `quantize_current` 使用 for 循环和实数运算，仅支持 SystemVerilog 或
//    Verilog-2001 以上仿真环境。
// 6. `SIMULATION 宏定义用于显示调试信息，实际仿真时需在编译命令行添加 `+define+SIMULATION`。
//
// 1. This module is a behavioral model intended for functional simulation and
//    architectural exploration only. It is NOT synthesizable.
// 2. Input current `i_in` is a SystemVerilog `real` array. If your simulator does not
//    support array ports, replace with 8 individual `real` ports: `input real i_in0, i_in1, ...`.
// 3. Conversion delay `ADC_DELAY_CYCLES` defaults to 8 cycles; adjust as needed.
// 4. Full-scale current `FULL_SCALE_CURRENT` is a normalized value; set it according to
//    actual voltage swing and transimpedance gain.
// 5. The `quantize_current` function uses for loops and real arithmetic, which requires
//    SystemVerilog or Verilog-2001 or later simulation environments.
// 6. The `SIMULATION macro is used for debug messages; add `+define+SIMULATION` to the
//    compilation command line to enable.

module adc_if #(
    parameter REAL_INPUT = 1,            // 1 = 输入为 real 类型电流 / Input is real type current
    parameter FULL_SCALE_CURRENT = 1.0,  // 满量程电流 (归一化值) / Full-scale current (normalized)
    parameter ADC_DELAY_CYCLES = 8       // 转换延迟周期数 / Conversion delay in cycles
) (
    input  wire         clk_i,       // 采样时钟 / Sampling clock
    input  wire         rst_n_i,     // 异步复位，低有效 / Async reset, active low
    input  wire         start_i,     // 启动转换信号 / Start conversion
    input  real         i_in [0:7],  // 8路模拟电流输入 (real) / 8-channel analog current input
    output reg          done_o,      // 转换完成标志 / Conversion done flag
    output reg  [2:0]   dout_o       // 3-bit 数字输出 / 3-bit digital output
);

    // ============================================================
    // 内部信号 / Internal Signals
    // ============================================================
    reg [2:0] adc_result;               // 转换结果寄存器
    reg [7:0] delay_cnt;                // 延迟计数器
    reg       converting;               // 转换中标志

    // ============================================================
    // ADC 转换状态机 / ADC Conversion State Machine
    // ============================================================
    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i) begin
            converting <= 1'b0;
            delay_cnt  <= 8'h0;
            done_o     <= 1'b0;
            dout_o     <= 3'b000;
            adc_result <= 3'b000;
        end else begin
            case (converting)
                1'b0: begin  // 空闲状态 / Idle state
                    done_o <= 1'b0;
                    if (start_i) begin
                        converting <= 1'b1;
                        delay_cnt  <= 8'h0;
                        // 在启动瞬间采样电流并量化 / Sample and quantize at start edge
                        adc_result <= quantize_current(i_in);
                    end
                end

                1'b1: begin  // 转换中状态 / Converting state
                    if (delay_cnt < ADC_DELAY_CYCLES - 1) begin
                        delay_cnt <= delay_cnt + 1;
                    end else begin
                        // 延迟结束，输出结果 / Delay completed, output result
                        dout_o     <= adc_result;
                        done_o     <= 1'b1;
                        converting <= 1'b0;
                    end
                end
            endcase
        end
    end

    // ============================================================
    // 电流量化函数 (3-bit Flash ADC 特性)
    // Current Quantization Function (3-bit Flash ADC characteristic)
    // ============================================================
    function [2:0] quantize_current;
        input real currents [0:7];
        real sum_current;
        real threshold_step;
        integer i;
        integer code;
        begin
            // 计算8路电流总和 / Sum of all 8 current channels
            sum_current = 0.0;
            for (i = 0; i < 8; i = i + 1) begin
                sum_current = sum_current + currents[i];
            end

            // 限幅至 [0, FULL_SCALE_CURRENT]
            // Clamp to [0, FULL_SCALE_CURRENT]
            if (sum_current < 0.0)
                sum_current = 0.0;
            if (sum_current > FULL_SCALE_CURRENT)
                sum_current = FULL_SCALE_CURRENT;

            // 3-bit 均匀量化: 8 个阈值 (0, 1/8, 2/8, ..., 7/8)
            // 3-bit uniform quantization: 8 thresholds
            threshold_step = FULL_SCALE_CURRENT / 8.0;

            code = 0;
            for (i = 0; i < 8; i = i + 1) begin
                if (sum_current >= (i * threshold_step))
                    code = i;
            end

            // 返回 3-bit 编码 / Return 3-bit code
            quantize_current = code[2:0];
        end
    endfunction

    // ============================================================
    // 仿真辅助：显示 ADC 状态 (非综合)
    // Simulation Helper: Display ADC status (not synthesizable)
    // ============================================================
`ifdef SIMULATION
    always @(posedge done_o) begin
        $display("[ADC] Conversion done: code = %d", dout_o);
    end
`endif

endmodule