// ============================================================
// Module: output_buffer
// Function: Output data buffer for Ming She chip
//           Stores inference results from the accumulator and
//           provides read access via the CSR interface.
// 功能：鸣蛇芯片输出数据缓存
//           存储来自累加器的推理结果，并通过 CSR 接口提供读访问。
// ============================================================
//
// 【注意事项 / Notes】
// 1. 本模块为纯数字逻辑，可综合。
// 2. 缓存深度为 8 个 16-bit 字，对应 8 个输出通道 (OUTPUT_CH0 – OUTPUT_CH7)。
// 3. 写操作由 FSM 在推理完成时发出的 `wr_i` 脉冲触发，同时 `addr_i` 选择通道。
// 4. 读操作由 CSR 在读 OUTPUT_CH* 寄存器时发出的 `rd_i` 和 `addr_i` 组合触发，
//    数据通过 `data_o` 组合逻辑立即返回（无延迟）。
// 5. 复位后所有缓存清零。
// 6. 写使能优先级高于读使能，但两者通常不会同时发生。
// 7. 输出数据位宽为 16-bit，与累加器输出一致。
// 8. 本模块无内部状态机，纯寄存器文件加组合逻辑读。
//
// 1. This module is pure digital logic and synthesizable.
// 2. Buffer depth is 8 words of 16-bit, corresponding to 8 output channels.
// 3. Write operation is triggered by a pulse on `wr_i` from FSM upon inference completion,
//    with `addr_i` selecting the channel.
// 4. Read operation is triggered by CSR when reading OUTPUT_CH* registers via `rd_i` and `addr_i`.
//    Data is returned immediately on `data_o` combinationally (zero delay).
// 5. All buffers are cleared on reset.
// 6. Write enable has priority over read enable, though they typically do not occur simultaneously.
// 7. Output data width is 16-bit, matching the accumulator output.
// 8. This module has no internal state machine; it is a pure register file with combinational read.

module output_buffer (
    input  wire         clk_i,
    input  wire         rst_n_i,

    // 写接口 (来自 FSM) / Write Interface (from FSM)
    input  wire         wr_i,           // 写使能脉冲 / Write enable pulse
    input  wire [2:0]   wr_addr_i,      // 写通道地址 (0-7) / Write channel address
    input  wire [15:0]  wr_data_i,      // 写数据 (来自累加器) / Write data (from accumulator)

    // 读接口 (到 CSR) / Read Interface (to CSR)
    input  wire         rd_i,           // 读使能 / Read enable
    input  wire [2:0]   rd_addr_i,      // 读通道地址 (0-7) / Read channel address
    output wire [15:0]  rd_data_o       // 读数据 / Read data
);

    // ============================================================
    // 缓存寄存器组 (8 × 16-bit) / Buffer Register File (8 × 16-bit)
    // ============================================================
    reg [15:0] buffer [0:7];

    // ============================================================
    // 写操作 / Write Operation
    // ============================================================
    integer i;
    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i) begin
            for (i = 0; i < 8; i = i + 1) begin
                buffer[i] <= 16'h0;
            end
        end else begin
            if (wr_i) begin
                buffer[wr_addr_i] <= wr_data_i;
            end
        end
    end

    // ============================================================
    // 读操作 (组合逻辑) / Read Operation (Combinational)
    // ============================================================
    reg [15:0] rd_data_reg;
    always @(*) begin
        if (rd_i) begin
            rd_data_reg = buffer[rd_addr_i];
        end else begin
            rd_data_reg = 16'h0;
        end
    end
    assign rd_data_o = rd_data_reg;

    // ============================================================
    // 仿真辅助 / Simulation Helper
    // ============================================================
`ifdef SIMULATION
    always @(posedge clk_i) begin
        if (wr_i)
            $display("[OUTBUF] Write ch=%d, data=0x%04h", wr_addr_i, wr_data_i);
        if (rd_i)
            $display("[OUTBUF] Read  ch=%d, data=0x%04h", rd_addr_i, rd_data_reg);
    end
`endif

endmodule