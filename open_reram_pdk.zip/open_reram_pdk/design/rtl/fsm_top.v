// ============================================================
// Module: fsm_top
// Function: Top-level finite state machine for Ming She chip
//           Coordinates weight programming, sensor data acquisition,
//           CIM array computation, ADC conversion, and accumulation.
// 功能：鸣蛇芯片顶层状态机
//           协调权重编程、传感器数据获取、存算阵列计算、ADC转换及累加。
// ============================================================
//
// 【注意事项 / Notes】
// 1. 本模块为纯数字逻辑，可综合。
// 2. 状态机采用二进制编码，复位后进入 IDLE 状态。
// 3. 权重编程阶段 (`LD_WEIGHT`) 逐单元进行，每个单元编程需等待 `weight_prog_done_i`。
//    实际编程脉冲由 `reram_ctrl` 生成，本状态机仅负责地址和数据控制。
// 4. 传感器数据请求通过 `sensor_req_o` 脉冲发起，数据有效由 `sensor_ready_i` 指示。
// 5. ADC 转换完成后，若需多周期累加，状态机返回 `WAIT_SENSOR` 继续下一块计算；
//    否则进入 `DONE` 状态。
// 6. 分块计算的控制参数（总块数、当前块索引）由参数 `NUM_TILES` 决定，此处默认单块。
//    若需支持多块，请扩展参数和内部计数器。
// 7. 输出信号 `busy_o` 在非 IDLE 状态时有效，`done_o` 在进入 DONE 状态时置位一个周期。
//
// 1. This module is pure digital logic and synthesizable.
// 2. State machine uses binary encoding and resets to IDLE state.
// 3. During weight programming (`LD_WEIGHT`), each cell is programmed sequentially,
//    waiting for `weight_prog_done_i` each time. Actual programming pulses are generated
//    by `reram_ctrl`; this FSM only controls address and data.
// 4. Sensor data is requested via a pulse on `sensor_req_o`; data validity is indicated
//    by `sensor_ready_i`.
// 5. After ADC conversion, if multi-cycle accumulation is required, the FSM returns to
//    `WAIT_SENSOR` for the next tile; otherwise it enters `DONE`.
// 6. Tile control parameters (total tiles, current tile index) are determined by parameter
//    `NUM_TILES`; currently defaults to single tile. Extend parameter and internal counters
//    for multi-tile support.
// 7. Output `busy_o` is asserted in any non-IDLE state. `done_o` is pulsed for one cycle
//    upon entering DONE state.

module fsm_top #(
    parameter NUM_TILES = 1              // 分块数量，默认1 / Number of tiles, default 1
) (
    input  wire         clk_i,
    input  wire         rst_n_i,

    // 控制接口 / Control Interface
    input  wire         start_i,         // 启动推理 / Start inference
    input  wire [1:0]   precision_i,     // 精度模式：00=INT4, 01=INT8 / Precision mode
    output reg          busy_o,          // 忙标志 / Busy flag
    output reg          done_o,          // 完成标志（脉冲）/ Done flag (pulse)

    // 权重编程接口 (到 ReRAM 控制器) / Weight Programming Interface (to ReRAM Controller)
    output reg          reram_wr_o,      // 写使能 / Write enable
    output reg  [3:0]   reram_row_o,     // 行地址 / Row address
    output reg  [3:0]   reram_col_o,     // 列地址 / Column address
    output reg  [7:0]   reram_wdata_o,   // 写数据（权重）/ Write data (weight)
    input  wire         weight_prog_done_i, // 单次编程完成 / Single programming done

    // 权重加载完成标志 (来自寄存器组，指示所有目标权重已配置) / Weight load complete flag
    input  wire         weight_all_loaded_i,

    // 存算阵列计算触发 (到 ReRAM 控制器) / CIM Array Compute Trigger (to ReRAM Controller)
    output reg          reram_rd_o,      // 读使能（触发矩阵乘法）/ Read enable (triggers MVM)

    // ADC 接口 / ADC Interface
    output reg          adc_start_o,     // 启动 ADC 转换 / Start ADC conversion
    input  wire         adc_done_i,      // ADC 转换完成 / ADC conversion done
    input  wire [2:0]   adc_data_i,      // ADC 输出数据 / ADC output data

    // 累加器接口 / Accumulator Interface
    output reg          accum_en_o,      // 累加使能 / Accumulator enable
    output reg          accum_rst_o,     // 累加器复位 / Accumulator reset
    input  wire [15:0]  accum_data_i,    // 累加结果 / Accumulated result

    // 传感器接口 / Sensor Interface
    output reg          sensor_req_o,    // 请求传感器数据 / Request sensor data
    input  wire         sensor_ready_i,  // 传感器数据有效 / Sensor data ready
    input  wire [7:0]   sensor_data_i    // 传感器数据 / Sensor data
);

    // ============================================================
    // 状态编码 / State Encoding
    // ============================================================
    localparam IDLE         = 4'd0,
               LD_WEIGHT    = 4'd1,
               WAIT_SENSOR  = 4'd2,
               COMPUTE      = 4'd3,
               ADC_CONV     = 4'd4,
               ACCUM        = 4'd5,
               CHECK_DONE   = 4'd6,
               DONE         = 4'd7;

    reg [3:0] state, next_state;

    // ============================================================
    // 内部计数器 / Internal Counters
    // ============================================================
    reg [7:0] row_cnt, col_cnt;          // 权重编程地址计数器
    reg [7:0] tile_cnt;                  // 当前分块计数（若 NUM_TILES > 1）

    // ============================================================
    // 状态寄存器 / State Register
    // ============================================================
    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i)
            state <= IDLE;
        else
            state <= next_state;
    end

    // ============================================================
    // 下一状态逻辑 / Next State Logic
    // ============================================================
    always @(*) begin
        next_state = state;
        case (state)
            IDLE: begin
                if (start_i) begin
                    if (!weight_all_loaded_i)
                        next_state = LD_WEIGHT;
                    else
                        next_state = WAIT_SENSOR;
                end
            end

            LD_WEIGHT: begin
                // 等待当前单元编程完成
                if (weight_prog_done_i) begin
                    // 若未完成全阵列编程，继续留在 LD_WEIGHT
                    // 编程地址在输出逻辑中更新
                    if ((row_cnt == 15) && (col_cnt == 15))
                        next_state = WAIT_SENSOR;  // 全阵列编程完成
                    else
                        next_state = LD_WEIGHT;
                end
            end

            WAIT_SENSOR: begin
                if (sensor_ready_i)
                    next_state = COMPUTE;
            end

            COMPUTE: begin
                // 计算耗时视为单周期，直接进入 ADC 等待
                next_state = ADC_CONV;
            end

            ADC_CONV: begin
                if (adc_done_i)
                    next_state = ACCUM;
            end

            ACCUM: begin
                // 累加完成后判断是否还有分块
                next_state = CHECK_DONE;
            end

            CHECK_DONE: begin
                if (tile_cnt < NUM_TILES - 1)
                    next_state = WAIT_SENSOR;
                else
                    next_state = DONE;
            end

            DONE: begin
                next_state = IDLE;
            end

            default: next_state = IDLE;
        endcase
    end

    // ============================================================
    // 输出逻辑与内部计数器更新 / Output Logic and Counter Updates
    // ============================================================
    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i) begin
            // 输出信号复位
            busy_o          <= 1'b0;
            done_o          <= 1'b0;
            reram_wr_o      <= 1'b0;
            reram_row_o     <= 4'h0;
            reram_col_o     <= 4'h0;
            reram_wdata_o   <= 8'h00;
            reram_rd_o      <= 1'b0;
            adc_start_o     <= 1'b0;
            accum_en_o      <= 1'b0;
            accum_rst_o     <= 1'b0;
            sensor_req_o    <= 1'b0;

            // 计数器复位
            row_cnt         <= 8'h0;
            col_cnt         <= 8'h0;
            tile_cnt        <= 8'h0;
        end else begin
            // 默认值
            busy_o          <= (state != IDLE);
            done_o          <= 1'b0;
            reram_wr_o      <= 1'b0;
            reram_rd_o      <= 1'b0;
            adc_start_o     <= 1'b0;
            accum_en_o      <= 1'b0;
            accum_rst_o     <= 1'b0;
            sensor_req_o    <= 1'b0;

            case (state)
                IDLE: begin
                    row_cnt  <= 8'h0;
                    col_cnt  <= 8'h0;
                    tile_cnt <= 8'h0;
                    accum_rst_o <= 1'b1;  // 复位累加器
                end

                LD_WEIGHT: begin
                    // 若未完成编程，则发出写命令
                    if (!weight_prog_done_i) begin
                        // 发出一次写脉冲（由 reram_ctrl 展宽）
                        reram_wr_o    <= 1'b1;
                        reram_row_o   <= row_cnt[3:0];
                        reram_col_o   <= col_cnt[3:0];
                        // 权重数据需从外部 CSR 获取，此处为占位值，实际使用时应连接到 CSR 输出
                        // 在实际顶层连接中，该信号来自 csr 模块的 cfg_weight_o
                        reram_wdata_o <= 8'h00;  // placeholder
                    end else begin
                        // 编程完成，更新地址
                        if (col_cnt == 15) begin
                            col_cnt <= 8'h0;
                            if (row_cnt == 15)
                                row_cnt <= 8'h0;
                            else
                                row_cnt <= row_cnt + 1;
                        end else begin
                            col_cnt <= col_cnt + 1;
                        end
                    end
                end

                WAIT_SENSOR: begin
                    sensor_req_o <= 1'b1;   // 持续请求，实际可改为脉冲
                end

                COMPUTE: begin
                    reram_rd_o  <= 1'b1;    // 触发存算阵列计算
                    adc_start_o <= 1'b1;    // 同时启动 ADC（计算与 ADC 流水）
                end

                ADC_CONV: begin
                    // 等待 ADC 完成，无新输出
                end

                ACCUM: begin
                    accum_en_o <= 1'b1;      // 累加使能
                end

                CHECK_DONE: begin
                    if (tile_cnt < NUM_TILES - 1) begin
                        tile_cnt <= tile_cnt + 1;
                        accum_rst_o <= 1'b0;  // 不清累加器，继续累加
                    end else begin
                        // 最后一轮，准备结束
                    end
                end

                DONE: begin
                    done_o <= 1'b1;
                end
            endcase
        end
    end

    // ============================================================
    // 仿真辅助：状态显示 / Simulation Helper: State Display
    // ============================================================
`ifdef SIMULATION
    always @(posedge clk_i) begin
        case (state)
            IDLE:        $display("[FSM] State: IDLE");
            LD_WEIGHT:   $display("[FSM] State: LD_WEIGHT (row=%d, col=%d)", row_cnt, col_cnt);
            WAIT_SENSOR: $display("[FSM] State: WAIT_SENSOR");
            COMPUTE:     $display("[FSM] State: COMPUTE");
            ADC_CONV:    $display("[FSM] State: ADC_CONV");
            ACCUM:       $display("[FSM] State: ACCUM");
            CHECK_DONE:  $display("[FSM] State: CHECK_DONE (tile=%d)", tile_cnt);
            DONE:        $display("[FSM] State: DONE");
        endcase
    end
`endif

endmodule