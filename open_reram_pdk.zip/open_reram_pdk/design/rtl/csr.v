// ============================================================
// Module: csr
// Function: Control and Status Register bank for Ming She chip
//           Stores configuration, input data, output results,
//           and performance monitoring values.
//           Provides interface to Wishbone bus and FSM.
// 功能：鸣蛇芯片控制与状态寄存器组
//           存储配置参数、输入数据、输出结果和性能监控值。
//           提供 Wishbone 总线和 FSM 的访问接口。
// ============================================================
//
// 【注意事项 / Notes】
// 1. 本模块为纯数字逻辑，可综合。
// 2. 寄存器地址映射详见 `docs/REGISTER_MAP.md`。偏移地址 0x00–0x6C。
// 3. 所有寄存器均为 32 位字对齐，字节/半字访问需由上层总线适配。
// 4. 写操作由 `we_i` 和 `addr_i` 组合控制，读操作为组合逻辑直接输出 `rdata_o`。
// 5. `STATUS.DONE` 位在以下条件清零：(a) 写入 `CTRL.START=1`；(b) 读取 `OUTPUT_CH0`。
// 6. `CTRL.START` 为自清零位，写 1 后硬件在启动 FSM 时自动清零。
// 7. `WEIGHT_CFG.WR_EN` 为自清零位，写 1 后硬件在编程完成时清零。
// 8. 输入通道数据 `INPUT_CH*` 在复位后清零。
// 9. 输出结果 `OUTPUT_CH*` 由硬件更新（来自累加器），软件只读。
// 10. 性能监控寄存器通过 `PMU_CTRL.SEL` 选择计数器，`PMU_VALUE` 返回当前值。
//
// 1. This module is pure digital logic and synthesizable.
// 2. Register address mapping is detailed in `docs/REGISTER_MAP.md`. Offsets 0x00–0x6C.
// 3. All registers are 32-bit word-aligned; byte/half-word access must be handled by upper bus layer.
// 4. Writes are controlled by `we_i` and `addr_i`; reads are combinational and output `rdata_o` directly.
// 5. `STATUS.DONE` is cleared when: (a) writing `CTRL.START=1`; (b) reading `OUTPUT_CH0`.
// 6. `CTRL.START` is self-clearing; hardware clears it automatically when starting FSM.
// 7. `WEIGHT_CFG.WR_EN` is self-clearing; hardware clears it automatically after programming done.
// 8. Input channel data `INPUT_CH*` are cleared on reset.
// 9. Output results `OUTPUT_CH*` are updated by hardware (from accumulator); software read-only.
// 10. PMU registers: `PMU_CTRL.SEL` selects counter, `PMU_VALUE` returns current value.

module csr (
    input  wire         clk_i,
    input  wire         rst_n_i,

    // Wishbone 接口 (来自 wishbone_if) / Wishbone Interface (from wishbone_if)
    input  wire         we_i,           // 写使能 / Write enable
    input  wire [7:0]   addr_i,         // 寄存器地址 (偏移) / Register address (offset)
    input  wire [31:0]  wdata_i,        // 写数据 / Write data
    output wire [31:0]  rdata_o,        // 读数据 / Read data

    // FSM 控制接口 / FSM Control Interface
    output wire         ctrl_start_o,   // 启动推理 / Start inference
    output wire [1:0]   ctrl_precision_o, // 精度模式 / Precision mode
    output wire [2:0]   ctrl_clk_div_o, // 传感器时钟分频 / Sensor clock divider
    input  wire         status_busy_i,  // FSM 忙标志 / FSM busy flag
    input  wire         status_done_i,  // FSM 完成标志 / FSM done flag
    input  wire         status_err_i,   // FSM 错误标志 / FSM error flag
    input  wire [3:0]   fsm_state_i,    // FSM 当前状态编码 / Current FSM state encoding
    input  wire [7:0]   err_code_i,     // 错误代码 / Error code

    // 权重配置接口 (到 FSM 和 reram_ctrl) / Weight Config Interface (to FSM and reram_ctrl)
    output wire [3:0]   cfg_row_o,      // 权重行地址 / Weight row address
    output wire [3:0]   cfg_col_o,      // 权重列地址 / Weight column address
    output wire [7:0]   cfg_weight_o,   // 权重数据 / Weight data
    output wire         cfg_wr_en_o,    // 权重写使能脉冲 / Weight write enable pulse
    input  wire         weight_prog_done_i, // 单次编程完成 (来自 reram_ctrl) / Single programming done
    input  wire         weight_all_loaded_i, // 全阵列编程完成 (来自内部逻辑) / All cells programmed

    // 输入通道数据 (到 sensor_if 或直接到存算阵列) / Input Channel Data (to sensor_if or CIM array)
    output wire [7:0]   input_ch0_o,
    output wire [7:0]   input_ch1_o,
    output wire [7:0]   input_ch2_o,
    output wire [7:0]   input_ch3_o,
    output wire [7:0]   input_ch4_o,
    output wire [7:0]   input_ch5_o,
    output wire [7:0]   input_ch6_o,
    output wire [7:0]   input_ch7_o,

    // 输入配置 / Input Configuration
    output wire [2:0]   input_ch_sel_o, // 通道选择 / Channel select
    output wire         sensor_mode_o,  // 传感器模式使能 / Sensor mode enable
    output wire [1:0]   sensor_type_o,  // 传感器协议类型 / Sensor protocol type
    output wire         chain_mode_o,   // 链式模式使能 / Chain mode enable

    // 输出结果 (来自累加器，由硬件更新) / Output Results (from accumulator, hardware updated)
    input  wire [15:0]  output_ch0_i,
    input  wire [15:0]  output_ch1_i,
    input  wire [15:0]  output_ch2_i,
    input  wire [15:0]  output_ch3_i,
    input  wire [15:0]  output_ch4_i,
    input  wire [15:0]  output_ch5_i,
    input  wire [15:0]  output_ch6_i,
    input  wire [15:0]  output_ch7_i,

    // PMU 接口 / PMU Interface
    output wire [3:0]   pmu_sel_o,      // 计数器选择 / Counter select
    output wire         pmu_capture_o,  // 捕获计数值 / Capture counter value
    output wire         pmu_clear_o,    // 清零计数器 / Clear counter
    input  wire [31:0]  pmu_value_i,    // 计数值 / Counter value
    input  wire [4:0]   pmu_overflow_i, // 溢出标志 / Overflow flags

    // 中断接口 / Interrupt Interface
    output wire         int_done_en_o,  // 完成中断使能 / Done interrupt enable
    output wire         int_err_en_o,   // 错误中断使能 / Error interrupt enable
    output wire         int_done_o,     // 完成中断请求 / Done interrupt request
    output wire         int_err_o       // 错误中断请求 / Error interrupt request
);

    // ============================================================
    // 寄存器地址定义 (与 REGISTER_MAP.md 保持一致)
    // Register Address Definitions (consistent with REGISTER_MAP.md)
    // ============================================================
    localparam ADDR_CTRL         = 8'h00,
               ADDR_STATUS       = 8'h04,
               ADDR_WEIGHT_CFG   = 8'h08,
               ADDR_INPUT_CFG    = 8'h0C,
               ADDR_INPUT_CH0    = 8'h10,
               ADDR_INPUT_CH1    = 8'h14,
               ADDR_INPUT_CH2    = 8'h18,
               ADDR_INPUT_CH3    = 8'h1C,
               ADDR_INPUT_CH4    = 8'h20,
               ADDR_INPUT_CH5    = 8'h24,
               ADDR_INPUT_CH6    = 8'h28,
               ADDR_INPUT_CH7    = 8'h2C,
               ADDR_OUTPUT_CH0   = 8'h30,
               ADDR_OUTPUT_CH1   = 8'h34,
               ADDR_OUTPUT_CH2   = 8'h38,
               ADDR_OUTPUT_CH3   = 8'h3C,
               ADDR_OUTPUT_CH4   = 8'h40,
               ADDR_OUTPUT_CH5   = 8'h44,
               ADDR_OUTPUT_CH6   = 8'h48,
               ADDR_OUTPUT_CH7   = 8'h4C,
               ADDR_PMU_CTRL     = 8'h50,
               ADDR_PMU_VALUE    = 8'h54,
               ADDR_PMU_STATUS   = 8'h58,
               ADDR_VERSION      = 8'h5C,
               ADDR_INT_EN       = 8'h60,
               ADDR_INT_STATUS   = 8'h64,
               ADDR_SCRATCH      = 8'h68;

    // ============================================================
    // 寄存器定义 / Register Declarations
    // ============================================================
    reg [31:0] ctrl_reg;
    reg [31:0] weight_cfg_reg;
    reg [31:0] input_cfg_reg;
    reg [31:0] input_ch_reg [0:7];
    reg [31:0] pmu_ctrl_reg;
    reg [31:0] int_en_reg;
    reg [31:0] int_status_reg;
    reg [31:0] scratch_reg;

    // 状态寄存器中的部分位由硬件更新，软件只读
    wire [31:0] status_reg;
    wire [31:0] pmu_status_reg;

    // 输出结果寄存器 (来自硬件，组合逻辑组装)
    wire [31:0] output_ch_reg [0:7];

    // 版本寄存器 (硬编码)
    wire [31:0] version_reg;
    assign version_reg = {8'h4D, 8'h26, 8'h04, 8'h01};  // 'M' 2026.04.01

    // ============================================================
    // 内部信号 / Internal Signals
    // ============================================================
    wire ctrl_start_bit;
    wire ctrl_abort_bit;
    wire ctrl_sw_rst_bit;
    wire weight_wr_en_bit;
    wire done_clear_from_read;

    // 寄存器写使能解码 / Register Write Enable Decoding
    wire wr_ctrl       = we_i && (addr_i == ADDR_CTRL);
    wire wr_weight_cfg = we_i && (addr_i == ADDR_WEIGHT_CFG);
    wire wr_input_cfg  = we_i && (addr_i == ADDR_INPUT_CFG);
    wire wr_input_ch0  = we_i && (addr_i == ADDR_INPUT_CH0);
    wire wr_input_ch1  = we_i && (addr_i == ADDR_INPUT_CH1);
    wire wr_input_ch2  = we_i && (addr_i == ADDR_INPUT_CH2);
    wire wr_input_ch3  = we_i && (addr_i == ADDR_INPUT_CH3);
    wire wr_input_ch4  = we_i && (addr_i == ADDR_INPUT_CH4);
    wire wr_input_ch5  = we_i && (addr_i == ADDR_INPUT_CH5);
    wire wr_input_ch6  = we_i && (addr_i == ADDR_INPUT_CH6);
    wire wr_input_ch7  = we_i && (addr_i == ADDR_INPUT_CH7);
    wire wr_pmu_ctrl   = we_i && (addr_i == ADDR_PMU_CTRL);
    wire wr_int_en     = we_i && (addr_i == ADDR_INT_EN);
    wire wr_int_status = we_i && (addr_i == ADDR_INT_STATUS);
    wire wr_scratch    = we_i && (addr_i == ADDR_SCRATCH);

    // 读操作信号 (用于自动清零 DONE 标志)
    wire rd_output_ch0 = (!we_i) && (addr_i == ADDR_OUTPUT_CH0);

    // ============================================================
    // 寄存器写入逻辑 / Register Write Logic
    // ============================================================
    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i) begin
            ctrl_reg       <= 32'h0;
            weight_cfg_reg <= 32'h0;
            input_cfg_reg  <= 32'h0;
            input_ch_reg[0] <= 32'h0;
            input_ch_reg[1] <= 32'h0;
            input_ch_reg[2] <= 32'h0;
            input_ch_reg[3] <= 32'h0;
            input_ch_reg[4] <= 32'h0;
            input_ch_reg[5] <= 32'h0;
            input_ch_reg[6] <= 32'h0;
            input_ch_reg[7] <= 32'h0;
            pmu_ctrl_reg   <= 32'h0;
            int_en_reg     <= 32'h0;
            int_status_reg <= 32'h0;
            scratch_reg    <= 32'h0;
        end else begin
            // 软件复位 (写 CTRL.SW_RST=1 时清零所有寄存器)
            if (wr_ctrl && wdata_i[4]) begin
                ctrl_reg       <= 32'h0;
                weight_cfg_reg <= 32'h0;
                input_cfg_reg  <= 32'h0;
                input_ch_reg[0] <= 32'h0;
                input_ch_reg[1] <= 32'h0;
                input_ch_reg[2] <= 32'h0;
                input_ch_reg[3] <= 32'h0;
                input_ch_reg[4] <= 32'h0;
                input_ch_reg[5] <= 32'h0;
                input_ch_reg[6] <= 32'h0;
                input_ch_reg[7] <= 32'h0;
                pmu_ctrl_reg   <= 32'h0;
                int_en_reg     <= 32'h0;
                int_status_reg <= 32'h0;
                scratch_reg    <= 32'h0;
            end else begin
                // 正常写入
                if (wr_ctrl) begin
                    // CTRL.START 写 1 置位，硬件会在启动 FSM 后清零
                    // 此处仅写入，自清零由组合逻辑输出处理
                    ctrl_reg <= wdata_i;
                end
                if (wr_weight_cfg)   weight_cfg_reg <= wdata_i;
                if (wr_input_cfg)    input_cfg_reg  <= wdata_i;
                if (wr_input_ch0)    input_ch_reg[0] <= wdata_i;
                if (wr_input_ch1)    input_ch_reg[1] <= wdata_i;
                if (wr_input_ch2)    input_ch_reg[2] <= wdata_i;
                if (wr_input_ch3)    input_ch_reg[3] <= wdata_i;
                if (wr_input_ch4)    input_ch_reg[4] <= wdata_i;
                if (wr_input_ch5)    input_ch_reg[5] <= wdata_i;
                if (wr_input_ch6)    input_ch_reg[6] <= wdata_i;
                if (wr_input_ch7)    input_ch_reg[7] <= wdata_i;
                if (wr_pmu_ctrl)     pmu_ctrl_reg   <= wdata_i;
                if (wr_int_en)       int_en_reg     <= wdata_i;
                if (wr_scratch)      scratch_reg    <= wdata_i;

                // 中断状态寄存器：写 1 清零
                if (wr_int_status) begin
                    int_status_reg <= int_status_reg & (~wdata_i);  // 写 1 的位清零
                end
            end

            // 硬件自动更新
            // (1) FSM 启动后清零 START 位
            if (ctrl_start_o && status_busy_i)
                ctrl_reg[0] <= 1'b0;

            // (2) 权重编程完成后清零 WR_EN 位
            if (weight_prog_done_i)
                weight_cfg_reg[16] <= 1'b0;

            // (3) 读取 OUTPUT_CH0 后清零 STATUS.DONE (由 done_clear_from_read 控制)
            //    STATUS 寄存器是组合逻辑从硬件信号组装，因此这里不做操作

            // (4) 硬件错误发生时置位 ERR 和 ERR_CODE (由组合逻辑处理，不在此处)

            // (5) 推理完成时硬件置位 DONE 中断标志
            if (status_done_i && int_en_reg[0])
                int_status_reg[0] <= 1'b1;
            if (status_err_i && int_en_reg[1])
                int_status_reg[1] <= 1'b1;
        end
    end

    // ============================================================
    // 状态寄存器组装 (组合逻辑) / Status Register Assembly (combinational)
    // ============================================================
    wire status_done_bit;
    assign status_done_bit = status_done_i && !done_clear_from_read;

    assign status_reg = {
        16'h0,                          // [31:16] 保留
        err_code_i,                     // [15:8] 错误代码
        fsm_state_i,                    // [7:4]  FSM 状态
        1'b0,                           // [3]    保留
        status_err_i,                   // [2]    ERR
        status_done_bit,                // [1]    DONE
        status_busy_i                   // [0]    BUSY
    };

    // DONE 标志清除逻辑：写 START=1 或读 OUTPUT_CH0 时清除
    assign done_clear_from_read = rd_output_ch0;
    // 注意：写 START=1 通过组合逻辑影响 DONE 显示，因为 status_done_i 来自 FSM，
    // FSM 在收到 start 后会清除自己的 done 输出，因此 status_done_i 自然会变低。

    // ============================================================
    // PMU 状态寄存器组装 / PMU Status Register Assembly
    // ============================================================
    assign pmu_status_reg = {
        27'h0,
        pmu_overflow_i                  // [4:0] 各计数器溢出标志
    };

    // ============================================================
    // 输出通道寄存器组装 / Output Channel Register Assembly
    // ============================================================
    assign output_ch_reg[0] = {16'h0, output_ch0_i};
    assign output_ch_reg[1] = {16'h0, output_ch1_i};
    assign output_ch_reg[2] = {16'h0, output_ch2_i};
    assign output_ch_reg[3] = {16'h0, output_ch3_i};
    assign output_ch_reg[4] = {16'h0, output_ch4_i};
    assign output_ch_reg[5] = {16'h0, output_ch5_i};
    assign output_ch_reg[6] = {16'h0, output_ch6_i};
    assign output_ch_reg[7] = {16'h0, output_ch7_i};

    // ============================================================
    // 读数据多路选择器 / Read Data Multiplexer
    // ============================================================
    reg [31:0] rdata_reg;
    always @(*) begin
        case (addr_i)
            ADDR_CTRL:        rdata_reg = ctrl_reg;
            ADDR_STATUS:      rdata_reg = status_reg;
            ADDR_WEIGHT_CFG:  rdata_reg = weight_cfg_reg;
            ADDR_INPUT_CFG:   rdata_reg = input_cfg_reg;
            ADDR_INPUT_CH0:   rdata_reg = input_ch_reg[0];
            ADDR_INPUT_CH1:   rdata_reg = input_ch_reg[1];
            ADDR_INPUT_CH2:   rdata_reg = input_ch_reg[2];
            ADDR_INPUT_CH3:   rdata_reg = input_ch_reg[3];
            ADDR_INPUT_CH4:   rdata_reg = input_ch_reg[4];
            ADDR_INPUT_CH5:   rdata_reg = input_ch_reg[5];
            ADDR_INPUT_CH6:   rdata_reg = input_ch_reg[6];
            ADDR_INPUT_CH7:   rdata_reg = input_ch_reg[7];
            ADDR_OUTPUT_CH0:  rdata_reg = output_ch_reg[0];
            ADDR_OUTPUT_CH1:  rdata_reg = output_ch_reg[1];
            ADDR_OUTPUT_CH2:  rdata_reg = output_ch_reg[2];
            ADDR_OUTPUT_CH3:  rdata_reg = output_ch_reg[3];
            ADDR_OUTPUT_CH4:  rdata_reg = output_ch_reg[4];
            ADDR_OUTPUT_CH5:  rdata_reg = output_ch_reg[5];
            ADDR_OUTPUT_CH6:  rdata_reg = output_ch_reg[6];
            ADDR_OUTPUT_CH7:  rdata_reg = output_ch_reg[7];
            ADDR_PMU_CTRL:    rdata_reg = pmu_ctrl_reg;
            ADDR_PMU_VALUE:   rdata_reg = pmu_value_i;
            ADDR_PMU_STATUS:  rdata_reg = pmu_status_reg;
            ADDR_VERSION:     rdata_reg = version_reg;
            ADDR_INT_EN:      rdata_reg = int_en_reg;
            ADDR_INT_STATUS:  rdata_reg = int_status_reg;
            ADDR_SCRATCH:     rdata_reg = scratch_reg;
            default:          rdata_reg = 32'h0;
        endcase
    end
    assign rdata_o = rdata_reg;

    // ============================================================
    // 控制信号输出 / Control Signal Outputs
    // ============================================================
    assign ctrl_start_o     = ctrl_reg[0];
    assign ctrl_precision_o = ctrl_reg[3:2];
    assign ctrl_clk_div_o   = ctrl_reg[7:5];

    assign cfg_row_o    = weight_cfg_reg[3:0];
    assign cfg_col_o    = weight_cfg_reg[7:4];
    assign cfg_weight_o = weight_cfg_reg[15:8];
    assign cfg_wr_en_o  = weight_cfg_reg[16];

    assign input_ch0_o = input_ch_reg[0][7:0];
    assign input_ch1_o = input_ch_reg[1][7:0];
    assign input_ch2_o = input_ch_reg[2][7:0];
    assign input_ch3_o = input_ch_reg[3][7:0];
    assign input_ch4_o = input_ch_reg[4][7:0];
    assign input_ch5_o = input_ch_reg[5][7:0];
    assign input_ch6_o = input_ch_reg[6][7:0];
    assign input_ch7_o = input_ch_reg[7][7:0];

    assign input_ch_sel_o = input_cfg_reg[2:0];
    assign sensor_mode_o  = input_cfg_reg[3];
    assign sensor_type_o  = input_cfg_reg[5:4];
    assign chain_mode_o   = input_cfg_reg[6];

    assign pmu_sel_o     = pmu_ctrl_reg[3:0];
    assign pmu_capture_o = pmu_ctrl_reg[4];
    assign pmu_clear_o   = pmu_ctrl_reg[5];

    assign int_done_en_o = int_en_reg[0];
    assign int_err_en_o  = int_en_reg[1];
    assign int_done_o    = int_status_reg[0] && int_en_reg[0];
    assign int_err_o     = int_status_reg[1] && int_en_reg[1];

    // ============================================================
    // 仿真辅助 / Simulation Helper
    // ============================================================
`ifdef SIMULATION
    always @(posedge clk_i) begin
        if (we_i)
            $display("[CSR] Write addr=0x%02h, data=0x%08h", addr_i, wdata_i);
        else if (addr_i != 8'h00)  // 避免在读空闲时刷屏
            $display("[CSR] Read  addr=0x%02h, data=0x%08h", addr_i, rdata_reg);
    end
`endif

endmodule