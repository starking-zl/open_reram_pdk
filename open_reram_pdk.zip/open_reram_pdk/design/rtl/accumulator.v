// ============================================================
// Module: accumulator
// Function: Multi-cycle accumulation for tiled matrix operations
// 功能：多周期累加器，用于分块矩阵运算
// ============================================================
//
// 【注意事项 / Notes】
// 1. 本模块为纯数字逻辑，可综合。
// 2. 累加器位宽固定为 16-bit，若需更大动态范围请自行扩展。
// 3. 复位信号 `rst_n_i` 为异步低有效，`rst_acc_i` 为同步复位（高有效）。
// 4. 输入数据 `data_i` 为 3-bit，在累加前会被零扩展至 16-bit。
//
// 1. This module is pure digital logic and synthesizable.
// 2. Accumulator width is fixed to 16-bit; extend if larger dynamic range is needed.
// 3. Reset `rst_n_i` is asynchronous active-low; `rst_acc_i` is synchronous active-high.
// 4. Input `data_i` is 3-bit and zero-extended to 16-bit before accumulation.

module accumulator (
    input  wire         clk_i,       // 系统时钟 / System clock
    input  wire         rst_n_i,     // 异步复位，低有效 / Async reset, active low
    input  wire         en_i,        // 累加使能 / Accumulation enable
    input  wire         rst_acc_i,   // 累加和同步复位，高有效 / Accumulator sync reset, active high
    input  wire [2:0]   data_i,      // 输入数据 (来自 ADC) / Input data (from ADC)
    output reg  [15:0]  result_o     // 累加结果 / Accumulated result
);

    // ============================================================
    // 累加寄存器 / Accumulation Register
    // ============================================================
    reg [15:0] acc_reg;

    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i) begin
            acc_reg <= 16'h0;
        end else if (rst_acc_i) begin
            // 同步复位累加和（通常在新一轮分块计算前使用）
            // Synchronously reset accumulation sum (typically used before a new tiled computation)
            acc_reg <= 16'h0;
        end else if (en_i) begin
            // 将 3-bit 输入零扩展为 16-bit 后累加
            // Zero-extend 3-bit input to 16-bit and accumulate
            acc_reg <= acc_reg + {13'h0, data_i};
        end
    end

    always @(posedge clk_i or negedge rst_n_i) begin
        if (!rst_n_i) begin
            result_o <= 16'h0;
        end else begin
            result_o <= acc_reg;
        end
    end

endmodule