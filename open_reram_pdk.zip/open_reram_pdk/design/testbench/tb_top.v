// ============================================================
// 声明 / Disclaimer
// 本测试平台仅用于功能仿真和架构验证，不可综合。
// 所有仿真结果均为行为级理想模型输出，不代表实际硅片性能。
// This testbench is for functional simulation and architectural
// validation only. It is not synthesizable. All simulation results
// are behavioral ideal model outputs and do not represent silicon.
// ============================================================
// ============================================================
// Testbench: tb_top
// Function: Top-level testbench for Ming She chip
//           Provides clock, reset, and basic Wishbone transaction
//           stimuli to verify functional correctness.
// 功能：鸣蛇芯片顶层测试平台
//           提供时钟、复位和基本的 Wishbone 事务激励，
//           用于验证功能正确性。
// ============================================================
//
// 【注意事项 / Notes】
// 1. 本测试平台仅用于功能仿真，不可综合。
// 2. 使用 `iverilog` 编译，通过 `vvp` 运行，生成 `tb_top.vcd` 波形文件。
// 3. 时钟周期设为 10ns (100MHz)，可根据需要调整。
// 4. 复位后执行简单的 Wishbone 写操作：配置权重，然后启动推理。
// 5. 推理完成后检查结果并打印仿真信息。
// 6. 由于本设计为行为级模型，仿真重点在于验证控制流与数据通路的正确性。
// 7. 若需更复杂的验证，请使用 Cocotb 框架（见 `cocotb_test.py`）。
//
// 1. This testbench is for functional simulation only; not synthesizable.
// 2. Compile with `iverilog` and run with `vvp`, generating `tb_top.vcd` waveform.
// 3. Clock period set to 10ns (100MHz); adjust as needed.
// 4. After reset, perform simple Wishbone writes: configure weights, then start inference.
// 5. Upon inference completion, check result and print simulation messages.
// 6. As this is a behavioral model, simulation focuses on control and data path correctness.
// 7. For more complex verification, use the Cocotb framework (see `cocotb_test.py`).

`timescale 1ns / 1ps

module tb_top;

    // ============================================================
    // 信号声明 / Signal Declarations
    // ============================================================
    reg         clk;
    reg         rst_n;

    // Wishbone 主端信号 / Wishbone Master Signals
    reg         wb_cyc;
    reg         wb_stb;
    reg         wb_we;
    reg  [31:0] wb_addr;
    reg  [31:0] wb_data_w;
    wire [31:0] wb_data_r;
    wire        wb_ack;
    wire        wb_err;

    // 传感器信号 / Sensor Signals
    wire        sen_clk;
    reg  [7:0]  sen_data;
    reg         sen_sync;

    // 中断信号 / Interrupt Signals
    wire        int_done;
    wire        int_err;

    // ============================================================
    // 待测设计例化 / DUT Instantiation
    // ============================================================
    top u_top (
        .clk        (clk),
        .rst_n      (rst_n),
        .wb_cyc_i   (wb_cyc),
        .wb_stb_i   (wb_stb),
        .wb_we_i    (wb_we),
        .wb_addr_i  (wb_addr),
        .wb_data_i  (wb_data_w),
        .wb_data_o  (wb_data_r),
        .wb_ack_o   (wb_ack),
        .wb_err_o   (wb_err),
        .sen_clk    (sen_clk),
        .sen_data   (sen_data),
        .sen_sync   (sen_sync),
        .int_done   (int_done),
        .int_err    (int_err)
    );

    // ============================================================
    // 时钟生成 / Clock Generation
    // ============================================================
    always #5 clk = ~clk;   // 100MHz clock

    // ============================================================
    // 仿真主流程 / Simulation Main Process
    // ============================================================
    initial begin
        // 波形转储 / Waveform dump
        $dumpfile("tb_top.vcd");
        $dumpvars(0, tb_top);

        // 初始化 / Initialization
        clk = 0;
        rst_n = 0;
        wb_cyc = 0;
        wb_stb = 0;
        wb_we = 0;
        wb_addr = 32'h0;
        wb_data_w = 32'h0;
        sen_data = 8'h00;
        sen_sync = 0;

        // 复位 / Reset
        repeat (5) @(posedge clk);
        rst_n = 1;
        repeat (5) @(posedge clk);

        $display("========================================");
        $display("[TB] Ming She Chip Simulation Started");
        $display("========================================");

        // --------------------------------------------------------
        // 步骤 1: 配置权重 (通过 Wishbone 写 WEIGHT_CFG 寄存器)
        // Step 1: Configure weights (via Wishbone write to WEIGHT_CFG)
        // --------------------------------------------------------
        // 示例：将 16x16 阵列的所有权重设为 1
        // 地址：0x08 (WEIGHT_CFG)
        // 数据：[16] WR_EN=1, [15:8] WEIGHT=1, [7:4] COL, [3:0] ROW
        $display("[TB] Programming weights...");
        for (int row = 0; row < 16; row = row + 1) begin
            for (int col = 0; col < 16; col = col + 1) begin
                wb_write(32'h08, {15'h0, 1'b1, 8'h01, col[3:0], row[3:0]});
                // 等待编程完成 (轮询 WEIGHT_CFG 的 WR_EN 位)
                wait_weight_prog_done();
            end
        end
        $display("[TB] Weight programming completed.");

        // --------------------------------------------------------
        // 步骤 2: 配置输入数据 (写 INPUT_CH0 – INPUT_CH7)
        // Step 2: Configure input data (write INPUT_CH0 – INPUT_CH7)
        // --------------------------------------------------------
        // 示例：设置所有输入通道为 8'h01
        $display("[TB] Configuring input channels...");
        for (int ch = 0; ch < 8; ch = ch + 1) begin
            wb_write(32'h10 + ch * 4, {24'h0, 8'h01});
        end

        // --------------------------------------------------------
        // 步骤 3: 配置输入模式为寄存器输入 (INPUT_CFG.SENSOR_MODE=0)
        // Step 3: Set input mode to register (INPUT_CFG.SENSOR_MODE=0)
        // --------------------------------------------------------
        wb_write(32'h0C, 32'h0);  // 全 0，使用寄存器输入

        // --------------------------------------------------------
        // 步骤 4: 启动推理 (写 CTRL.START=1)
        // Step 4: Start inference (write CTRL.START=1)
        // --------------------------------------------------------
        $display("[TB] Starting inference...");
        wb_write(32'h00, {31'h0, 1'b1});  // CTRL.START=1

        // --------------------------------------------------------
        // 步骤 5: 等待完成 (轮询 STATUS.DONE 或等待中断)
        // Step 5: Wait for completion (poll STATUS.DONE or wait interrupt)
        // --------------------------------------------------------
        wait (int_done == 1'b1);
        $display("[TB] Inference done! Reading result...");

        // --------------------------------------------------------
        // 步骤 6: 读取输出结果 (读 OUTPUT_CH0)
        // Step 6: Read output result (read OUTPUT_CH0)
        // --------------------------------------------------------
        wb_read(32'h30, result);
        $display("[TB] OUTPUT_CH0 = 0x%04h", result[15:0]);

        // --------------------------------------------------------
        // 步骤 7: 检查结果 (期望值: 16 * 8 * 1 = 128 = 0x0080)
        // Step 7: Check result (expected: 16 * 8 * 1 = 128 = 0x0080)
        // --------------------------------------------------------
        if (result[15:0] == 16'h0080) begin
            $display("[TB] TEST PASSED!");
        end else begin
            $display("[TB] TEST FAILED! Expected 0x0080, got 0x%04h", result[15:0]);
        end

        $display("========================================");
        $display("[TB] Simulation Finished");
        $display("========================================");
        #100 $finish;
    end

    // ============================================================
    // Wishbone 写任务 / Wishbone Write Task
    // ============================================================
    task automatic wb_write(input [31:0] addr, input [31:0] data);
        begin
            @(posedge clk);
            wb_cyc <= 1;
            wb_stb <= 1;
            wb_we  <= 1;
            wb_addr <= addr;
            wb_data_w <= data;
            // 等待应答
            wait (wb_ack == 1 || wb_err == 1);
            @(posedge clk);
            wb_cyc <= 0;
            wb_stb <= 0;
            wb_we  <= 0;
            if (wb_err) begin
                $display("[TB] Wishbone write error at addr=0x%08h", addr);
            end
        end
    endtask

    // ============================================================
    // Wishbone 读任务 / Wishbone Read Task
    // ============================================================
    task automatic wb_read(input [31:0] addr, output [31:0] data);
        begin
            @(posedge clk);
            wb_cyc <= 1;
            wb_stb <= 1;
            wb_we  <= 0;
            wb_addr <= addr;
            // 等待应答
            wait (wb_ack == 1 || wb_err == 1);
            data = wb_data_r;
            @(posedge clk);
            wb_cyc <= 0;
            wb_stb <= 0;
            if (wb_err) begin
                $display("[TB] Wishbone read error at addr=0x%08h", addr);
            end
        end
    endtask

    // ============================================================
    // 等待权重编程完成 / Wait for Weight Programming Done
    // ============================================================
    task automatic wait_weight_prog_done();
        reg [31:0] status;
        begin
            do begin
                wb_read(32'h08, status);
            end while (status[16] == 1'b1);  // WR_EN 位为 1 表示仍在编程
        end
    endtask

    // ============================================================
    // 传感器行为模型 (简单示例) / Sensor Behavioral Model (simple)
    // ============================================================
    // 这里仅提供一个静态值，实际可根据需要扩展
    always @(posedge sen_clk) begin
        // 在传感器模式下，当 FSM 请求数据时，返回模拟值
        if (u_top.u_fsm_top.sensor_req_o) begin
            sen_data <= 8'h01;   // 返回固定值 1
            sen_sync <= 1'b1;
        end else begin
            sen_sync <= 1'b0;
        end
    end

endmodule