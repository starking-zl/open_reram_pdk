# ============================================================
# 声明 / Disclaimer
# 本测试脚本仅用于功能仿真和架构验证。所有仿真结果均为
# 行为级理想模型输出，不代表实际硅片性能。
# This test script is for functional simulation and architectural
# validation only. All simulation results are behavioral ideal
# model outputs and do not represent actual silicon performance.
# ============================================================
#!/usr/bin/env python3
# ============================================================
# Cocotb Testbench for Ming She Chip
# 鸣蛇芯片 Cocotb 测试平台
# ============================================================

import cocotb
from cocotb.triggers import Timer, RisingEdge, FallingEdge
from cocotb.clock import Clock
from cocotb.result import TestSuccess, TestFailure

# 寄存器地址定义（与 CSR 一致）
ADDR_CTRL        = 0x00
ADDR_STATUS      = 0x04
ADDR_WEIGHT_CFG  = 0x08
ADDR_INPUT_CFG   = 0x0C
ADDR_INPUT_CH0   = 0x10
ADDR_OUTPUT_CH0  = 0x30

@cocotb.test()
async def test_basic_inference(dut):
    """基础推理测试：配置权重、启动推理、检查结果"""
    
    # 时钟生成
    clock = Clock(dut.clk, 10, units='ns')
    cocotb.start_soon(clock.start())
    
    # 复位
    dut.rst_n.value = 0
    await Timer(100, units='ns')
    dut.rst_n.value = 1
    await Timer(100, units='ns')
    
    # Wishbone 总线初始化
    dut.wb_cyc_i.value = 0
    dut.wb_stb_i.value = 0
    dut.wb_we_i.value = 0
    
    dut._log.info("Starting Ming She basic inference test...")
    
    # 步骤 1: 编程权重（这里只编程一个单元作为示例）
    await wb_write(dut, ADDR_WEIGHT_CFG, 0x00010000 | (0 << 0) | (0 << 4))  # row=0, col=0, weight=1, WR_EN=1
    await wait_weight_prog_done(dut)
    dut._log.info("Weight programmed.")
    
    # 步骤 2: 配置输入
    await wb_write(dut, ADDR_INPUT_CH0, 0x00000001)
    
    # 步骤 3: 启动推理
    await wb_write(dut, ADDR_CTRL, 0x00000001)
    
    # 步骤 4: 等待完成
    await wait_for_done(dut)
    
    # 步骤 5: 读取结果
    result = await wb_read(dut, ADDR_OUTPUT_CH0)
    dut._log.info(f"Output result: {result:#x}")
    
    # 简单的期望值检查（可根据实际调整）
    expected = 0x0001  # 仅一个单元激活，1 * 1 = 1
    if result & 0xFFFF == expected:
        dut._log.info("TEST PASSED")
        raise TestSuccess()
    else:
        dut._log.error(f"TEST FAILED: expected {expected:#x}, got {result:#x}")
        raise TestFailure()

# ============================================================
# Wishbone 读写辅助函数
# ============================================================
async def wb_write(dut, addr, data):
    dut.wb_cyc_i.value = 1
    dut.wb_stb_i.value = 1
    dut.wb_we_i.value = 1
    dut.wb_addr_i.value = addr
    dut.wb_data_i.value = data
    await RisingEdge(dut.clk)
    while not dut.wb_ack_o.value and not dut.wb_err_o.value:
        await RisingEdge(dut.clk)
    dut.wb_cyc_i.value = 0
    dut.wb_stb_i.value = 0
    await RisingEdge(dut.clk)

async def wb_read(dut, addr):
    dut.wb_cyc_i.value = 1
    dut.wb_stb_i.value = 1
    dut.wb_we_i.value = 0
    dut.wb_addr_i.value = addr
    await RisingEdge(dut.clk)
    while not dut.wb_ack_o.value and not dut.wb_err_o.value:
        await RisingEdge(dut.clk)
    data = dut.wb_data_o.value
    dut.wb_cyc_i.value = 0
    dut.wb_stb_i.value = 0
    await RisingEdge(dut.clk)
    return data

async def wait_weight_prog_done(dut):
    while True:
        val = await wb_read(dut, ADDR_WEIGHT_CFG)
        if (val >> 16) & 1 == 0:
            break

async def wait_for_done(dut):
    while True:
        status = await wb_read(dut, ADDR_STATUS)
        if status & 0x2:  # DONE bit
            break
        await RisingEdge(dut.clk)