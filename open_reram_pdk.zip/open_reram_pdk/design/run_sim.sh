# ============================================================
# 声明：本脚本用于 Icarus Verilog 功能仿真，不涉及实际流片。
# Disclaimer: This script is for Icarus Verilog functional
# simulation only, not for physical tape-out.
# ============================================================
#!/bin/bash
# ============================================================
# 仿真运行脚本 / Simulation Run Script
# 使用 Icarus Verilog (iverilog) 编译并运行鸣蛇芯片顶层仿真
# ============================================================

cd "$(dirname "$0")"

# 文件列表 / File List
# 注意：顺序不重要，但必须包含所有模块
FILES="
../reram/macros/reram_8x8/reram_8x8.v
../reram/macros/adc_3bit/adc_3bit.v
rtl/reram_array_16x16.v
rtl/adc_if.v
rtl/accumulator.v
rtl/fsm_top.v
rtl/reram_ctrl.v
rtl/wishbone_if.v
rtl/csr.v
rtl/sensor_if.v
rtl/output_buffer.v
rtl/pmu.v
rtl/top.v
testbench/tb_top.v
"

# 编译 / Compile
iverilog -o simv $FILES

if [ $? -eq 0 ]; then
    echo "=========================================="
    echo "Compilation successful. Running simulation..."
    echo "=========================================="
    vvp simv
else
    echo "=========================================="
    echo "Compilation failed. Please check errors above."
    echo "=========================================="
    exit 1
fi

# 可选：打开波形查看器（需要 GTKWave）
# gtkwave tb_top.vcd &