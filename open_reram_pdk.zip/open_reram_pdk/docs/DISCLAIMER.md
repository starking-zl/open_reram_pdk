# 未经流片测试声明 / Disclaimer of Untested Silicon

## 中文声明

本开源 PDK（工艺设计套件）及其中包含的所有工艺参数、器件模型、设计规则、标准单元库、宏单元和示例设计 **均未经实际硅片制造和物理测试验证**。

使用者必须明确知晓并同意以下条款：

1. **仅供学术与研究用途**  
   本 PDK 的设计目的仅限于学术研究、架构探索、算法验证及教学演示。任何基于本 PDK 生成的 GDSII 版图文件均不得直接提交至晶圆代工厂进行实际生产。

2. **性能数据均为理论值**  
   所有通过仿真获得的时序、功耗、面积、良率及能效数据均基于简化模型或理想条件计算得出，与实际硅片表现可能存在显著差异。

3. **不承担法律责任**  
   本项目维护者及贡献者对因使用本 PDK 或其衍生设计而造成的任何直接或间接损失（包括但不限于流片失败、产品故障、商业损失）不承担任何法律或经济责任。

4. **必须替换为商用 PDK 方可流片**  
   若您计划将设计投入实际制造，必须从目标晶圆代工厂获取官方授权的商用 PDK，并使用其提供的模型、规则和标准单元库替换本项目中对应的全部内容。

使用本项目即表示您已阅读、理解并同意上述所有条款。

---

## English Disclaimer

This open-source PDK (Process Design Kit) and all included process parameters, device models, design rules, standard cell libraries, macros, and example designs **have NOT been verified through actual silicon fabrication or physical testing**.

By using this PDK, you acknowledge and agree to the following terms:

1. **Academic and Research Use Only**  
   This PDK is intended solely for academic research, architectural exploration, algorithm validation, and educational purposes. Any GDSII layout files generated using this PDK must NOT be submitted to any semiconductor foundry for physical manufacturing.

2. **Performance Data are Theoretical Estimates**  
   All timing, power, area, yield, and energy efficiency data obtained through simulation are based on simplified models or idealized conditions. Significant deviations from actual silicon behavior are to be expected.

3. **No Liability Assumed**  
   The maintainers and contributors of this project assume no legal or financial responsibility for any direct or indirect damages arising from the use of this PDK or derivative designs, including but not limited to tape-out failures, product malfunctions, or commercial losses.

4. **Commercial PDK Replacement Required for Fabrication**  
   If you intend to fabricate a design based on this work, you must obtain an officially licensed commercial PDK from your target foundry and replace all models, rules, and standard cell libraries contained herein with the foundry‑provided equivalents.

Your use of this project constitutes acceptance of all the above terms.