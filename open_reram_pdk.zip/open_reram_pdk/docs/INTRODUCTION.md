# 项目介绍 / Project Introduction

## 中文介绍

### 项目名称
**开源存算一体芯片设计平台（理论极限探索版）**  
Open CIM PDK — Theoretical Limit Exploration Edition

### 项目定位
本项目是一个 **纯虚拟的、未经流片验证的** 芯片设计研究平台。它不追求商业量产，也不承诺任何物理可实现性，而是致力于探索在理想条件下，基于 ReRAM 的存算一体架构能够达到的理论能效边界与设计方法学极限。

### 核心原则
- **理论极限优先**：所有架构决策以最大化能效和算力密度为目标，不向制造可行性妥协。
- **完全开源**：从器件模型到 RTL 设计、从仿真脚本到约束文件，全部源代码公开，无闭源商业 IP 依赖。
- **只设计，不流片**：本项目产出为 GDSII 版图文件及详尽的仿真验证报告，**不进行任何实际流片**。所有性能数据均标注为“理论仿真值”。
- **透明局限性**：在全部文档中明确声明模型简化、规则未验证等局限性，杜绝误导性宣传。

### 适用场景
- 存算一体架构的学术研究与教学
- AI 推理芯片设计方法学的算法级验证
- 开源 EDA 工具链的流程演示与能力评估
- 新架构、新器件的早期虚拟原型探索

### 快速开始
1. 克隆本仓库至本地（或直接使用 `open_reram_pdk/` 目录）。
2. 阅读 `docs/` 下的声明与报告，了解平台限制。
3. 进入 `design/` 目录，参考 `rtl/` 中的模块划分，开始填充 RTL 代码。
4. 使用 `run_sim.sh`（需 iverilog）或 `run_cocotb.sh`（需 cocotb）进行功能仿真。

---

## English Introduction

### Project Name
**Open CIM PDK — Theoretical Limit Exploration Edition**

### Positioning
This project is a **purely virtual, silicon‑unverified** chip design research platform. It does not target commercial production, nor does it guarantee any physical realizability. Its sole purpose is to explore the theoretical energy‑efficiency limits and design methodology boundaries of ReRAM‑based compute‑in‑memory architectures under idealized conditions.

### Core Principles
- **Theoretical Limits First**: All architectural decisions prioritize maximum energy efficiency and computational density, without compromise for manufacturability.
- **Fully Open Source**: From device models to RTL design, from simulation scripts to constraint files, all source code is publicly available with no dependency on closed‑source commercial IP.
- **Design Only, No Tape‑Out**: The deliverables of this project are GDSII layout files and comprehensive simulation reports. **No physical fabrication will be performed**. All performance figures are explicitly labeled as “theoretical simulation values.”
- **Transparent Limitations**: All documentation clearly states the simplifications and unverified nature of the models and rules, preventing any misleading claims.

### Intended Use Cases
- Academic research and teaching of compute‑in‑memory architectures
- Algorithm‑level validation of AI inference chip design methodologies
- Flow demonstration and capability evaluation of open‑source EDA toolchains
- Early virtual prototyping of novel architectures and emerging devices

### Quick Start
1. Clone this repository (or directly use the `open_reram_pdk/` directory).
2. Read the disclaimers and reports in `docs/` to understand the platform's limitations.
3. Navigate to the `design/` directory, refer to the module partitioning in `rtl/`, and begin writing RTL code.
4. Run `run_sim.sh` (requires iverilog) or `run_cocotb.sh` (requires cocotb) for functional simulation.