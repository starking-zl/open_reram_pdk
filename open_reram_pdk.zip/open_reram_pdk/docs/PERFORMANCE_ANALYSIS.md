# 理论性能分析报告 / Theoretical Performance Analysis Report

## 鸣蛇 (Ming She) 芯片

**文档版本 / Document Revision**: 0.1.0  
**最后更新 / Last Updated**: 2026-04-23


---

## 1. 分析前提与假设 / Analysis Assumptions and Hypotheses

本报告基于以下理论假设与设计参数进行推算。所有数值均为理想条件下的理论极限值，**未经硅验证**。

This analysis is based on the following theoretical assumptions and design parameters. All values represent ideal theoretical limits and **have NOT been silicon‑verified**.

| 参数 / Parameter | 假设值 / Assumed Value | 来源 / Source |
|:---|:---|:---|
| 工艺节点 / Process Node | 28nm (CMOS + BEOL ReRAM) | 规格书定义 |
| 存算阵列规模 / CIM Array Size | 16×16 (256 cells) | 架构设计 |
| 时钟频率 / Clock Frequency | 200 MHz | 基于28nm典型时序估算 |
| 单次乘累加操作数 / MACs per Cycle | 512 ops (16×16×2) | 架构设计 |
| ADC 量化位宽 / ADC Resolution | 3‑bit | 架构设计 |
| ADC 转换延迟 / ADC Latency | 8 cycles | 行为模型参数 |
| 系统级功耗估算 / System Power | 3.5 mW | 见第3节详细拆解 |


---

## 2. 算力分析 / Throughput Analysis

### 2.1 阵列级峰值算力 / Array‑Level Peak Throughput

| 项目 / Item | 公式 / Formula | 数值 / Value |
|:---|:---|:---|
| 单周期乘累加数 / MACs per Cycle | 16 × 16 × 2 | 512 ops |
| 时钟频率 / Frequency | f = 200 MHz | 200 MHz |
| 阵列级峰值算力 / Array Peak Throughput | 512 × 200M | **102.4 GMAC/s** |
| 等效 INT8 TOPS | 102.4 × 2 / 1000 | **≈ 0.2048 TOPS** |

*注：1 MAC = 2 OPs（乘加各一），INT8 算力换算系数为 2。*

### 2.2 系统级有效算力 / System‑Level Effective Throughput

考虑 ADC 转换开销与分块累加开销，有效算力低于阵列级峰值。

| 项目 / Item | 数值 / Value |
|:---|:---|
| 单次 16×16 矩阵乘法所需周期 / Cycles per MVM | 1 (计算) + 8 (ADC) = 9 |
| 有效算力 / Effective Throughput | 102.4 × (1 / 9) ≈ **11.38 GMAC/s** |
| 等效 INT8 TOPS | **≈ 0.0228 TOPS** |

### 2.3 多 Bank 扩展算力 / Multi‑Bank Scaling

若将存算阵列扩展为 4 个 16×16 Bank 并行，算力线性提升。

| Bank 数量 / Number of Banks | 峰值算力 / Peak Throughput | 有效算力 / Effective Throughput |
|:---|:---|:---|
| 1 (当前设计) | 0.2048 TOPS | 0.0228 TOPS |
| 4 | 0.8192 TOPS | 0.0912 TOPS |
| 16 | 3.2768 TOPS | 0.3648 TOPS |

*注：多 Bank 扩展需额外设计仲裁、数据分发与结果汇聚逻辑，功耗和面积同步增长。*


---

## 3. 能效分析 / Energy Efficiency Analysis

### 3.1 系统功耗拆解 / System Power Breakdown

基于 28nm 典型参数与存算一体文献数据估算。

| 功耗组件 / Power Component | 估算值 / Estimated Value | 说明 / Remarks |
|:---|:---|:---|
| ReRAM 阵列静态漏电 / Array Leakage | 0.2 mW | 1.2V 偏置，256 单元 |
| 模拟计算动态功耗 / Analog Compute Dynamic | 0.5 mW | 200MHz 输入翻转率 |
| ADC 功耗 / ADC Power | 0.8 mW | 3‑bit Flash ADC，4 通道轮询 |
| 数字逻辑功耗 / Digital Logic | 1.5 mW | 控制状态机、总线、寄存器 |
| 时钟树功耗 / Clock Tree | 0.5 mW | 200MHz，门控时钟 |
| **总计 / Total** | **≈ 3.5 mW** | 系统级估算 |

### 3.2 能效指标 / Energy Efficiency Metrics

| 指标 / Metric | 公式 / Formula | 数值 / Value |
|:---|:---|:---|
| 阵列级峰值能效 / Array Peak Efficiency | 0.2048 TOPS / 3.5 mW | **≈ 58.5 TOPS/W** |
| 系统级有效能效 / System Effective Efficiency | 0.0228 TOPS / 3.5 mW | **≈ 6.5 TOPS/W** |

### 3.3 4‑Bank 扩展能效 / 4‑Bank Extended Efficiency

| 指标 / Metric | 数值 / Value |
|:---|:---|
| 4‑Bank 峰值算力 / Peak Throughput | 0.8192 TOPS |
| 4‑Bank 总功耗 / Total Power | ≈ 6.0 mW |
| 4‑Bank 峰值能效 / Peak Efficiency | **≈ 136.5 TOPS/W** |


---

## 4. 推理延迟分析 / Inference Latency Analysis

| 任务场景 / Task Scenario | 数据尺寸 / Data Size | 所需周期 / Cycles | 延迟 @200MHz / Latency |
|:---|:---|:---|:---|
| 单次 16×16 矩阵向量乘 / Single 16×16 MVM | 16×16 | 9 | 45 ns |
| 64×64 矩阵分块计算 / Tiled 64×64 | 64×64 | 16 × 9 + 累加 ≈ 150 | 750 ns |
| 典型关键词识别 (KWS) / Keyword Spotting | ~30k 参数 | ~2000 | 10 µs |
| 轻量视觉唤醒 (MobileNet‑V1 lite) | ~2M MACs | ~20000 | 100 µs |

*注：以上延迟仅为存算阵列计算时间，未包含传感器数据采集和总线传输开销。*


---

## 5. 与文献对比 / Comparison with Published Works

| 芯片 / Chip | 工艺 / Process | 存算阵列 / CIM Array | 精度 / Precision | 系统能效 / System Efficiency | 备注 / Remarks |
|:---|:---|:---|:---|:---|:---|
| **鸣蛇 (本设计)** | 28nm (假设) | 16×16 ReRAM | INT8 | 6.5 TOPS/W (有效) | 理论估算值，未流片 |
| **鸣蛇 4‑Bank 扩展** | 28nm (假设) | 4×16×16 ReRAM | INT8 | 136.5 TOPS/W (峰值) | 理论扩展估算 |
| ISSCC 2024 CIM 芯片 | 28nm | 64×64 SRAM | INT8 | 24.5 TOPS/W | 硅验证，系统级 |
| 亿铸科技 ReRAM | 28nm | 未公开 | INT8 | 35.4 TOPS/W | 硅验证，系统级 |
| 犀灵视觉感存算一体 | 55nm | 未公开 | INT4 | 346 TOPS/W | ISSCC 2026，全模拟域 |

**对比解读 / Interpretation**：
- 本设计**单 Bank 系统级有效能效 6.5 TOPS/W**，处于合理区间（ADC 开销显著）。
- **4‑Bank 扩展后峰值能效 136.5 TOPS/W**，接近当前最先进的 ReRAM 存算一体芯片水平，验证了架构的理论潜力。
- 若进一步采用**感存算一体**架构消除 ADC 开销，理论能效可再提升一个数量级，但设计与验证复杂度急剧增加。


---

## 6. 面积估算 / Area Estimation

| 模块 / Module | 估算面积 / Estimated Area | 依据 / Basis |
|:---|:---|:---|
| 16×16 ReRAM 阵列 | 0.05 mm² | 28nm ReRAM 单元面积约 0.2 µm²/bit |
| ADC (4× 3‑bit Flash) | 0.02 mm² | 典型 Flash ADC 面积 |
| 数字逻辑 (控制器、总线、寄存器) | 0.15 mm² | 约 20k 门，28nm 标准单元密度 |
| SRAM (64 KB) | 0.30 mm² | 28nm 高密度 SRAM |
| **总计 / Total** | **≈ 0.52 mm²** | 不含 IO Pads |

4‑Bank 扩展后面积约为 **1.5–2.0 mm²**。


---

## 7. 理论极限讨论 / Theoretical Limit Discussion

### 7.1 能效瓶颈分析 / Energy Efficiency Bottleneck

当前设计的能效瓶颈在于 **ADC 转换开销**。ADC 功耗占总功耗约 23%，但其带来的延迟（8 周期）导致有效算力下降为峰值的 1/9。

**优化方向**：
- 采用更低位宽 ADC（如 1‑bit 比较器）或完全消除 ADC（感存算一体）。
- 增加存算阵列并行度（多 Bank），摊薄 ADC 相对开销。

### 7.2 精度‑能效权衡 / Precision‑Efficiency Trade‑off

若降级为 INT4 精度，阵列规模不变，峰值算力翻倍（INT4 算力换算系数为 4），但模型精度可能下降 1–3%。此为应用场景相关的取舍。

### 7.3 工艺缩放潜力 / Process Scaling Potential

假设工艺从 28nm 迁移至 16nm：
- 时钟频率可提升至 400–500 MHz（约 2–2.5×）。
- 数字逻辑功耗降低约 40%。
- ReRAM 单元面积缩小，但阻变材料特性需重新标定。

理论峰值能效可再提升 **2–3 倍**。


---

## 8. 结论 / Conclusion

鸣蛇芯片在 **28nm 假设工艺**下，单 Bank 系统级有效能效为 **6.5 TOPS/W**，4‑Bank 扩展后峰值能效可达 **136.5 TOPS/W**。该数值与已发表的同工艺 ReRAM 存算一体芯片处于同一量级，验证了本开源架构设计的理论合理性。

本分析报告所有数据均为基于公开文献与理想模型的**理论推算值**，未经过硅验证。实际芯片表现将受工艺偏差、寄生效应、工作温度等因素影响，可能与推算值存在显著差异。

本报告的价值在于：为存算一体架构的学术研究提供一个**可复现、可扩展的性能分析框架**。


---

## 9. 声明 / Disclaimer

**中文声明**  
本报告中的所有性能数据均为基于公开文献、简化模型与理想条件的**理论推算值**，未经任何晶圆代工厂的实际制造与测试验证。实际硅片表现可能与本文档描述存在显著差异。本报告仅供学术研究与架构探索参考，不可直接用于商业产品规格定义。

**English Disclaimer**  
All performance figures in this report are **theoretical estimates** derived from public literature, simplified models, and idealized assumptions. They have NOT been verified through actual fabrication or testing by any semiconductor foundry. Actual silicon behavior may differ significantly from descriptions herein. This report is intended solely for academic research and architectural exploration, and MUST NOT be used to define commercial product specifications.

---