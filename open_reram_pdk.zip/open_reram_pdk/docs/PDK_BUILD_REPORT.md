# PDK 构建与仿真验证报告 / PDK Construction and Simulation Report

## 中文部分

### 1. 概述
本文档记录开源存算一体芯片设计平台（Open CIM PDK）的构建过程、仿真环境配置及模型局限性。本平台以 SkyWater 130nm 开源 PDK 为基础，集成了 ReRAM 器件的行为级模型，旨在为存算一体架构的学术研究提供一套完全开放的虚拟设计环境。

### 2. PDK 目录结构与关键文件
| 路径 | 描述 | 状态 |
| :--- | :--- | :--- |
| `sky130/libs.ref/` | 标准单元库参考文件（LEF/LIB/Verilog） | 精简骨架，仅供流程验证 |
| `sky130/libs.tech/` | 工艺技术文件（Magic、SPICE） | 部分层映射为占位值，待对齐官方数据 |
| `reram/models/` | ReRAM 器件模型 | 简化行为级模型，无法模拟开关瞬态与变异性 |
| `reram/macros/reram_8x8/` | 8×8 存算一体宏单元 | 行为级 Verilog 模型，乘累加逻辑待扩展为全8路 |
| `reram/macros/adc_3bit/` | 3-bit ADC 宏单元 | 仅空壳占位，尚未实现功能模型 |

### 3. 仿真环境与工具链
- **数字仿真**：Icarus Verilog (iverilog) + GTKWave
- **高级验证**：Cocotb (Python‑based testbench)
- **SPICE 仿真**：Ngspice（仅用于 ReRAM 单元直流特性分析）
- **物理实现**：OpenLane + Magic（理论流程，未经实际布线验证）

### 4. 模型局限性说明
- **ReRAM 器件模型**：当前 `reram_cell.sp` 为理想开关行为描述，不包含 cycle‑to‑cycle 变异、保持失效、Forming 瞬态等物理效应。精确仿真需替换为北京大学 Verilog‑A 物理模型或商用代工厂提供的 SPICE 模型。
- **标准单元库**：Liberty 文件仅包含 `NAND2_X1` 和 `INV_X1` 两个单元，且无实际时序数值。逻辑综合结果不具备时序参考价值。
- **工艺规则**：Magic 技术文件中的 GDS 层号映射为基于公开资料的推测值，与 SkyWater 官方 PDK 可能存在差异。生成 GDSII 前必须使用官方 `sky130A.tech` 进行交叉验证。

### 5. 下一步计划
- [ ] 补充 8×8 宏单元的全功能 Verilog 模型
- [ ] 实现基于 Cocotb 的完整验证环境
- [ ] 编写 OpenLane 自动化设计脚本（仅流程演示）
- [ ] 完善设计约束文件（SDC）中的多工艺角配置

---

## English Section

### 1. Overview
This document records the construction process, simulation environment setup, and model limitations of the Open CIM (Computing‑In‑Memory) PDK. Built upon the SkyWater 130nm open‑source PDK and integrated with behavioral ReRAM device models, this platform provides a fully open virtual design environment for academic research on compute‑in‑memory architectures.

### 2. Directory Structure and Key Files
| Path | Description | Status |
| :--- | :--- | :--- |
| `sky130/libs.ref/` | Standard cell reference files (LEF/LIB/Verilog) | Minimal skeleton for flow validation only |
| `sky130/libs.tech/` | Technology files (Magic, SPICE) | Some layer mappings are placeholders; official data alignment required |
| `reram/models/` | ReRAM device models | Simplified behavioral model; does not simulate switching transients or variability |
| `reram/macros/reram_8x8/` | 8×8 CIM macro | Behavioral Verilog; multiply‑accumulate logic needs extension to full 8 channels |
| `reram/macros/adc_3bit/` | 3‑bit ADC macro | Placeholder shell; functional model not yet implemented |

### 3. Simulation Environment and Toolchain
- **Digital Simulation**: Icarus Verilog (iverilog) + GTKWave
- **Advanced Verification**: Cocotb (Python‑based testbench)
- **SPICE Simulation**: Ngspice (currently only for ReRAM cell DC analysis)
- **Physical Implementation**: OpenLane + Magic (theoretical flow, not verified with actual routing)

### 4. Model Limitations
- **ReRAM Device Model**: The current `reram_cell.sp` is an idealized switch description and does not include physical effects such as cycle‑to‑cycle variability, retention failure, or forming transients. For accurate simulation, replace with the Peking University Verilog‑A physical model or a foundry‑provided SPICE model.
- **Standard Cell Library**: The Liberty file contains only `NAND2_X1` and `INV_X1` cells and lacks actual timing values. Synthesis results have no timing significance.
- **Process Rules**: GDS layer number mappings in the Magic technology file are inferred from public documentation and may differ from the official SkyWater PDK. Cross‑validation with the official `sky130A.tech` is mandatory before GDSII generation.

### 5. Next Steps
- [ ] Complete full‑function Verilog model for the 8×8 macro
- [ ] Implement a comprehensive Cocotb‑based verification environment
- [ ] Draft OpenLane automation scripts (flow demonstration only)
- [ ] Refine multi‑corner configurations in the SDC constraints file