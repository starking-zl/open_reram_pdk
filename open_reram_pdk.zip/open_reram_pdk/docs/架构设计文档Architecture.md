# 架构设计文档 / Architecture Design Document

## 鸣蛇 (Ming She) 芯片

**文档版本 / Document Revision**: 0.1.0  
**最后更新 / Last Updated**: 2026-04-23


---

## 1. 架构概述 / Architectural Overview

鸣蛇芯片采用 **数字控制域 + 模拟存算域** 的异构架构。数字部分负责总线通信、状态调度与结果后处理；模拟部分以 16×16 ReRAM 存算阵列为核心，在模拟域完成矩阵-向量乘法，仅通过 3-bit ADC 将最终结果传回数字域。

The Ming She chip adopts a heterogeneous architecture combining a **digital control domain** and an **analog CIM domain**. The digital part handles bus communication, state scheduling, and result post‑processing; the analog part centers on a 16×16 ReRAM CIM array, performing matrix‑vector multiplication entirely in the analog domain and returning only the final result to the digital domain via a 3‑bit ADC.

### 1.1 设计哲学 / Design Philosophy

- **最小化模数转换开销 / Minimize ADC Overhead**  
  仅在存算阵列输出端放置低精度 ADC，避免每通道独立 ADC 带来的面积与功耗膨胀。

- **流式数据通路 / Streaming Data Path**  
  传感器数据直接灌入存算阵列，无需经数字域缓存，最大限度降低唤醒延迟。

- **状态机驱动 / FSM‑Driven**  
  全部操作由硬件状态机调度，无需 CPU 干预，实现真正的 Always‑on 自主推理。


---

## 2. 顶层模块划分 / Top‑Level Module Partition

| 模块名称 / Module Name | 所属域 / Domain | 功能摘要 / Function Summary |
|:---|:---|:---|
| `wb_if` | 数字 | Wishbone B4 从机接口，处理寄存器读写 |
| `csr` | 数字 | 控制/状态寄存器组，存储配置与状态标志 |
| `pmu` | 数字 | 性能监控单元，统计周期数、利用率等 |
| `fsm_top` | 数字 | 顶层状态机，调度推理全流程 |
| `reram_ctrl` | 数字 | ReRAM 阵列控制器，生成编程/读取时序 |
| `reram_array_16x16` | 模拟 | 16×16 ReRAM 存算一体阵列核心 |
| `adc_if` | 混合 | 3‑bit 电流型 ADC 接口，完成模拟电流到数字量的转换 |
| `accumulator` | 数字 | 多周期累加器，支持大于 16×16 的矩阵分块计算 |
| `sensor_if` | 数字 | 传感器并行接口，兼容 PDM/I2S/并口 ADC 等协议 |
| `output_buffer` | 数字 | 推理结果缓存，对齐 Wishbone 读时序 |

模块间连接关系详见第 5 节连接表。

Detailed inter‑module connectivity is provided in Section 5 Connection Table.


---

## 3. 模块接口定义 / Module Interface Definitions

### 3.1 `wb_if` —— Wishbone 从机接口

| 信号 / Signal | 位宽 / Width | 方向 / Dir | 描述 / Description |
|:---|:---|:---|:---|
| `wb_clk_i` | 1 | in | 总线时钟 |
| `wb_rst_n_i` | 1 | in | 异步复位，低有效 |
| `wb_cyc_i` | 1 | in | 总线周期有效 |
| `wb_stb_i` | 1 | in | 选通 |
| `wb_we_i` | 1 | in | 写使能 |
| `wb_addr_i` | 32 | in | 地址 |
| `wb_data_i` | 32 | in | 写数据 |
| `wb_data_o` | 32 | out | 读数据 |
| `wb_ack_o` | 1 | out | 应答 |
| `csr_we_o` | 1 | out | 寄存器写使能，送至 `csr` |
| `csr_addr_o` | 8 | out | 寄存器地址（偏移量） |
| `csr_wdata_o` | 32 | out | 寄存器写数据 |
| `csr_rdata_i` | 32 | in | 寄存器读数据（来自 `csr`） |

### 3.2 `csr` —— 控制/状态寄存器组

| 信号 / Signal | 位宽 / Width | 方向 / Dir | 描述 / Description |
|:---|:---|:---|:---|
| `clk_i` | 1 | in | 系统时钟 |
| `rst_n_i` | 1 | in | 异步复位 |
| `we_i` | 1 | in | 写使能 |
| `addr_i` | 8 | in | 寄存器地址 |
| `wdata_i` | 32 | in | 写数据 |
| `rdata_o` | 32 | out | 读数据 |
| `ctrl_start_o` | 1 | out | 启动推理 |
| `ctrl_precision_o` | 2 | out | 精度模式：00=INT4, 01=INT8, 1x=保留 |
| `status_busy_i` | 1 | in | FSM 忙标志 |
| `status_done_i` | 1 | in | 推理完成标志 |
| `cfg_row_o` | 4 | out | 权重配置行地址 |
| `cfg_col_o` | 4 | out | 权重配置列地址 |
| `cfg_weight_o` | 8 | out | 权重值 (INT8) |
| `input_ch0_o` ~ `input_ch7_o` | 各 8 | out | 8 通道输入数据 |
| `output_ch0_i` ~ `output_ch7_i` | 各 16 | in | 推理结果（来自累加器） |
| `pmu_select_o` | 4 | out | PMU 计数器选择 |
| `pmu_value_i` | 32 | in | PMU 计数值 |

### 3.3 `fsm_top` —— 顶层状态机

| 信号 / Signal | 位宽 / Width | 方向 / Dir | 描述 / Description |
|:---|:---|:---|:---|
| `clk_i` | 1 | in | 系统时钟 |
| `rst_n_i` | 1 | in | 异步复位 |
| `start_i` | 1 | in | 启动信号（来自 `csr`） |
| `precision_i` | 2 | in | 精度模式 |
| `busy_o` | 1 | out | 忙标志 |
| `done_o` | 1 | out | 完成标志 |
| `reram_wr_o` | 1 | out | ReRAM 写使能 |
| `reram_row_o` | 4 | out | 行地址 |
| `reram_col_o` | 4 | out | 列地址 |
| `reram_wdata_o` | 8 | out | 写数据（权重） |
| `reram_rd_o` | 1 | out | ReRAM 读使能（触发计算） |
| `adc_start_o` | 1 | out | ADC 转换启动 |
| `adc_done_i` | 1 | in | ADC 转换完成 |
| `adc_data_i` | 3 | in | ADC 输出数据 |
| `accum_en_o` | 1 | out | 累加器使能 |
| `accum_rst_o` | 1 | out | 累加器复位 |
| `accum_data_i` | 16 | in | 累加器结果 |
| `sensor_req_o` | 1 | out | 请求传感器数据 |
| `sensor_ready_i` | 1 | in | 传感器数据有效 |
| `sensor_data_i` | 8 | in | 传感器数据 |

### 3.4 `reram_ctrl` —— ReRAM 控制器

| 信号 / Signal | 位宽 / Width | 方向 / Dir | 描述 / Description |
|:---|:---|:---|:---|
| `clk_i` | 1 | in | 系统时钟 |
| `rst_n_i` | 1 | in | 异步复位 |
| `wr_i` | 1 | in | 写使能（权重编程） |
| `rd_i` | 1 | in | 读使能（触发矩阵乘法） |
| `row_i` | 4 | in | 行地址 |
| `col_i` | 4 | in | 列地址 |
| `wdata_i` | 8 | in | 写数据（权重） |
| `array_wr_o` | 1 | out | 阵列写脉冲 |
| `array_row_o` | 4 | out | 阵列行地址 |
| `array_col_o` | 4 | out | 阵列列地址 |
| `array_wdata_o` | 8 | out | 阵列写数据 |
| `array_vin_o` | 8 | out | 阵列输入电压（数字表示） |

### 3.5 `reram_array_16x16` —— 存算阵列（行为模型）

| 信号 / Signal | 位宽 / Width | 方向 / Dir | 描述 / Description |
|:---|:---|:---|:---|
| `wr_i` | 1 | in | 写使能（编程权重） |
| `row_i` | 4 | in | 行地址 |
| `col_i` | 4 | in | 列地址 |
| `wdata_i` | 8 | in | 权重值 |
| `vin_i` | 8×8 | in | 8 路输入电压（数字表示，每路 8‑bit） |
| `iout_o` | 8 | out | 8 路电流输出（模拟值，仿真中用实数表示） |

*注：在实际仿真中，`iout_o` 使用 `real` 类型或定点数表示电流和。*

### 3.6 `adc_if` —— 3‑bit ADC 接口

| 信号 / Signal | 位宽 / Width | 方向 / Dir | 描述 / Description |
|:---|:---|:---|:---|
| `clk_i` | 1 | in | 采样时钟 |
| `rst_n_i` | 1 | in | 异步复位 |
| `start_i` | 1 | in | 启动转换 |
| `i_in` | 8 | in | 8 路模拟电流输入（仿真中用 `real`） |
| `done_o` | 1 | out | 转换完成 |
| `dout_o` | 3 | out | 3‑bit 数字输出 |

### 3.7 `accumulator` —— 累加器

| 信号 / Signal | 位宽 / Width | 方向 / Dir | 描述 / Description |
|:---|:---|:---|:---|
| `clk_i` | 1 | in | 系统时钟 |
| `rst_n_i` | 1 | in | 异步复位 |
| `en_i` | 1 | in | 累加使能 |
| `rst_acc_i` | 1 | in | 累加和复位 |
| `data_i` | 3 | in | ADC 输入数据 |
| `result_o` | 16 | out | 累加结果 |

### 3.8 `sensor_if` —— 传感器接口

| 信号 / Signal | 位宽 / Width | 方向 / Dir | 描述 / Description |
|:---|:---|:---|:---|
| `clk_i` | 1 | in | 系统时钟 |
| `rst_n_i` | 1 | in | 异步复位 |
| `req_i` | 1 | in | 请求数据 |
| `mode_i` | 2 | in | 传感器协议模式（00=PDM, 01=I2S, 10=Parallel） |
| `sen_clk_o` | 1 | out | 传感器时钟输出 |
| `sen_data_i` | 8 | in | 传感器数据输入 |
| `sen_sync_i` | 1 | in | 帧同步 |
| `ready_o` | 1 | out | 数据有效 |
| `data_o` | 8 | out | 输出数据（至存算阵列） |

### 3.9 `output_buffer` —— 输出缓存

| 信号 / Signal | 位宽 / Width | 方向 / Dir | 描述 / Description |
|:---|:---|:---|:---|
| `clk_i` | 1 | in | 系统时钟 |
| `rst_n_i` | 1 | in | 异步复位 |
| `wr_i` | 1 | in | 写使能（来自 FSM 的 done 脉冲） |
| `data_i` | 16 | in | 累加结果 |
| `rd_i` | 1 | in | 读使能（来自 `csr` 读请求） |
| `data_o` | 16 | out | 输出数据（至 `csr`） |


---

## 4. 顶层状态机设计 / Top‑Level FSM Design

### 4.1 状态定义 / State Definition

| 状态 / State | 编码 / Encoding | 描述 / Description |
|:---|:---|:---|
| `IDLE` | 4'b0000 | 空闲，等待启动信号 |
| `LD_WEIGHT` | 4'b0001 | 加载权重：通过 Wishbone 逐单元编程 ReRAM 阵列 |
| `WAIT_SENSOR` | 4'b0010 | 等待传感器数据就绪 |
| `COMPUTE` | 4'b0011 | 触发存算阵列进行一次矩阵-向量乘法 |
| `ADC_CONV` | 4'b0100 | 等待 ADC 转换完成 |
| `ACCUM` | 4'b0101 | 累加器更新（若需多周期） |
| `CHECK_DONE` | 4'b0110 | 判断是否完成全部计算 |
| `DONE` | 4'b0111 | 推理完成，置位完成标志，返回 IDLE |

### 4.2 状态跳转图 / State Transition Diagram

```mermaid
stateDiagram-v2
    [*] --> IDLE
    IDLE --> LD_WEIGHT : start_i=1 且权重未加载
    IDLE --> WAIT_SENSOR : start_i=1 且权重已加载
    LD_WEIGHT --> LD_WEIGHT : 未完成全部权重编程
    LD_WEIGHT --> WAIT_SENSOR : 权重编程完成
    WAIT_SENSOR --> COMPUTE : sensor_ready_i=1
    COMPUTE --> ADC_CONV : 存算阵列计算完成
    ADC_CONV --> ACCUM : adc_done_i=1
    ACCUM --> CHECK_DONE : 累加完成
    CHECK_DONE --> WAIT_SENSOR : 未完成全部分块计算
    CHECK_DONE --> DONE : 全部分块计算完成
    DONE --> IDLE : 自动返回
```
*中文注释 / Chinese Annotations*
- `IDLE`：空闲状态，等待 `start_i` 启动信号。
- `LD_WEIGHT`：加载权重状态，通过 Wishbone 总线逐单元编程 ReRAM 阵列。
- `WAIT_SENSOR`：等待传感器数据就绪状态。
- `COMPUTE`：触发存算阵列执行一次矩阵-向量乘法。
- `ADC_CONV`：等待 ADC 转换完成。
- `ACCUM`：累加器更新状态（用于多周期分块计算）。
- `CHECK_DONE`：检查是否完成全部分块。
- `DONE`：推理完成，置位完成标志后自动返回 `IDLE`。

*English Annotations*
- `IDLE`: Idle state, waiting for `start_i` assertion.
- `LD_WEIGHT`: Weight loading state, programming ReRAM cells via Wishbone bus.
- `WAIT_SENSOR`: Waiting for sensor data ready.
- `COMPUTE`: Triggering one matrix-vector multiplication in the CIM array.
- `ADC_CONV`: Waiting for ADC conversion completion.
- `ACCUM`: Accumulator update state (for multi-cycle tiled computation).
- `CHECK_DONE`: Checking whether all tiles are completed.
- `DONE`: Inference finished; sets the done flag and returns to `IDLE`.

### 4.3 状态转移条件 / Transition Conditions

| 当前状态 / Current | 下一状态 / Next | 条件 / Condition |
|:---|:---|:---|
| `IDLE` | `LD_WEIGHT` | `start_i == 1` 且权重未加载 |
| `IDLE` | `WAIT_SENSOR` | `start_i == 1` 且权重已加载 |
| `LD_WEIGHT` | `LD_WEIGHT` | 未完成全部权重编程 |
| `LD_WEIGHT` | `WAIT_SENSOR` | 权重编程完成 |
| `WAIT_SENSOR` | `COMPUTE` | `sensor_ready_i == 1` |
| `COMPUTE` | `ADC_CONV` | 存算阵列计算完成（单周期固定延迟） |
| `ADC_CONV` | `ACCUM` | `adc_done_i == 1` |
| `ACCUM` | `CHECK_DONE` | 累加完成 |
| `CHECK_DONE` | `WAIT_SENSOR` | 未完成全部分块计算 |
| `CHECK_DONE` | `DONE` | 全部分块计算完成 |
| `DONE` | `IDLE` | 自动返回 |


---

## 5. 模块间连接关系 / Inter‑Module Connectivity

### 5.1 数字域连接表 / Digital Domain Connections

| 源模块 / Source | 源信号 / Signal | 目标模块 / Destination | 目标信号 / Signal |
|:---|:---|:---|:---|
| `wb_if` | `csr_we_o` | `csr` | `we_i` |
| `wb_if` | `csr_addr_o` | `csr` | `addr_i` |
| `wb_if` | `csr_wdata_o` | `csr` | `wdata_i` |
| `csr` | `csr_rdata_i` | `wb_if` | `rdata_o` |
| `csr` | `ctrl_start_o` | `fsm_top` | `start_i` |
| `csr` | `ctrl_precision_o` | `fsm_top` | `precision_i` |
| `fsm_top` | `status_busy_o` | `csr` | `status_busy_i` |
| `fsm_top` | `status_done_o` | `csr` | `status_done_i` |
| `csr` | `cfg_row_o` | `fsm_top` | 内部寄存器，由 FSM 读取 |
| `csr` | `cfg_col_o` | `fsm_top` | 内部寄存器，由 FSM 读取 |
| `csr` | `cfg_weight_o` | `fsm_top` | 内部寄存器，由 FSM 读取 |
| `fsm_top` | `reram_wr_o` | `reram_ctrl` | `wr_i` |
| `fsm_top` | `reram_rd_o` | `reram_ctrl` | `rd_i` |
| `fsm_top` | `reram_row_o` | `reram_ctrl` | `row_i` |
| `fsm_top` | `reram_col_o` | `reram_ctrl` | `col_i` |
| `fsm_top` | `reram_wdata_o` | `reram_ctrl` | `wdata_i` |
| `reram_ctrl` | `array_vin_o` | `reram_array_16x16` | `vin_i` |
| `fsm_top` | `adc_start_o` | `adc_if` | `start_i` |
| `adc_if` | `adc_done_o` | `fsm_top` | `adc_done_i` |
| `adc_if` | `adc_data_o` | `fsm_top` | `adc_data_i` |
| `fsm_top` | `accum_en_o` | `accumulator` | `en_i` |
| `fsm_top` | `accum_rst_o` | `accumulator` | `rst_acc_i` |
| `accumulator` | `result_o` | `fsm_top` | `accum_data_i` |
| `fsm_top` | `sensor_req_o` | `sensor_if` | `req_i` |
| `sensor_if` | `ready_o` | `fsm_top` | `sensor_ready_i` |
| `sensor_if` | `data_o` | `fsm_top` | `sensor_data_i` |
| `fsm_top` | 内部 `done` 脉冲 | `output_buffer` | `wr_i` |
| `accumulator` | `result_o` | `output_buffer` | `data_i` |
| `csr` | 读请求（组合逻辑） | `output_buffer` | `rd_i` |
| `output_buffer` | `data_o` | `csr` | `output_ch*_i` |
| `csr` | `pmu_select_o` | `pmu` | `select_i` |
| `pmu` | `value_o` | `csr` | `pmu_value_i` |

### 5.2 模拟域连接表 / Analog Domain Connections

| 源模块 / Source | 源信号 / Signal | 目标模块 / Destination | 目标信号 / Signal |
|:---|:---|:---|:---|
| `reram_ctrl` | `array_wr_o` | `reram_array_16x16` | `wr_i` |
| `reram_ctrl` | `array_row_o` | `reram_array_16x16` | `row_i` |
| `reram_ctrl` | `array_col_o` | `reram_array_16x16` | `col_i` |
| `reram_ctrl` | `array_wdata_o` | `reram_array_16x16` | `wdata_i` |
| `reram_array_16x16` | `iout_o` | `adc_if` | `i_in` |


---

## 6. 寄存器位域详细定义 / Register Bit‑Field Definitions

详见配套文档 `REGISTER_MAP.md`。此处仅列出关键寄存器概要。

Refer to the companion document `REGISTER_MAP.md` for full details. Below is a summary of key registers.

| 偏移 / Offset | 名称 / Name | 位域 / Bit Fields |
|:---|:---|:---|
| `0x00` | `CTRL` | [0] start, [1] 保留, [3:2] precision, [4] sw_rst |
| `0x04` | `STATUS` | [0] busy, [1] done, [2] err, [7:4] state_code |
| `0x08` | `WEIGHT_CFG` | [11:8] row, [7:4] col, [15:12] 保留, [31:16] weight_data |
| `0x0C` | `INPUT_CFG` | [2:0] channel_sel, [31:8] 保留 |
| `0x10` ~ `0x2C` | `INPUT_CH0` ~ `INPUT_CH7` | [7:0] data, [31:8] 保留 |
| `0x30` ~ `0x4C` | `OUTPUT_CH0` ~ `OUTPUT_CH7` | [15:0] result, [31:16] 保留 |
| `0x50` | `PMU_CTRL` | [3:0] counter_sel, [8] capture |
| `0x54` | `PMU_VALUE` | [31:0] counter_value |


---

## 7. 关键时序说明 / Key Timing Specifications

### 7.1 权重配置时序 / Weight Programming Timing

```mermaid
sequenceDiagram
    participant SW as 软件 / Software
    participant WB as Wishbone 总线 / Wishbone Bus
    participant CSR as 寄存器组 / CSR
    participant FSM as 状态机 / FSM
    participant Array as ReRAM 阵列 / ReRAM Array

    SW->>WB: 写 WEIGHT_CFG (ROW, COL, WEIGHT, WR_EN=1)
    WB->>CSR: 更新 WEIGHT_CFG
    CSR->>FSM: 触发 weight_req
    FSM->>Array: 发出编程脉冲 (wr_i, row_i, col_i, wdata_i)
    Note over Array: 内部高压编程时序 (~100ns)
    FSM-->>CSR: 清除 WR_EN 标志
    CSR-->>WB: 读 WEIGHT_CFG 返回 WR_EN=0
    WB-->>SW: 确认编程完成
```

**时序说明 / Timing Description**
- 软件写 `WEIGHT_CFG` 寄存器，设置目标地址、权重值及 `WR_EN=1`。
- 硬件检测到 `WR_EN` 上升沿后，启动内部编程状态机。
- 编程脉冲宽度约 100 ns（基于 28nm ReRAM 典型值）。
- 编程完成后硬件自动清零 `WR_EN`，软件可通过轮询该位确认完成。
- 连续编程多个单元时，需逐个写入并等待完成。

*English*
- Software writes `WEIGHT_CFG` register with target address, weight value, and `WR_EN=1`.
- Hardware detects rising edge of `WR_EN` and starts internal programming FSM.
- Programming pulse width is approximately 100 ns (based on 28nm ReRAM typical values).
- Hardware clears `WR_EN` automatically after programming; software may poll this bit to confirm completion.
- For multiple cells, write and wait sequentially.


### 7.2 推理执行时序 / Inference Execution Timing

```mermaid
sequenceDiagram
    participant SW as 软件 / Software
    participant FSM as 状态机 / FSM
    participant Sensor as 传感器接口 / Sensor IF
    participant Array as 存算阵列 / CIM Array
    participant ADC as ADC 接口 / ADC IF
    participant Acc as 累加器 / Accumulator

    SW->>FSM: 写 CTRL.START=1
    activate FSM
    FSM->>Sensor: 请求数据 (req_i)
    Sensor-->>FSM: 返回 ready + data
    FSM->>Array: 加载输入向量 (vin_i)
    Note over Array: 模拟域矩阵乘法 (~2ns)
    FSM->>ADC: 启动转换 (start_i)
    ADC-->>FSM: done + 3-bit 数据
    FSM->>Acc: 累加使能 (en_i)
    Acc-->>FSM: 累加结果
    FSM-->>SW: 置 STATUS.DONE=1
    deactivate FSM
```

**时序说明 / Timing Description**
- 软件写 `CTRL.START=1` 启动推理。
- 状态机请求传感器数据（若配置为传感器模式），数据就绪后加载至存算阵列。
- 模拟域矩阵乘法的计算延迟极短（约 2 ns，受限于导线 RC），可视为单周期完成。
- ADC 转换需多个周期（取决于 ADC 架构，此处假设 8 周期）。
- 若需多周期累加，累加器在每次 ADC 完成后更新。
- 全部计算完成后，硬件置 `STATUS.DONE=1`，可选触发中断。

*English*
- Software writes `CTRL.START=1` to initiate inference.
- FSM requests sensor data (if in sensor mode); upon readiness, data is loaded into the CIM array.
- Analog matrix multiplication delay is negligible (~2 ns, limited by wire RC) and treated as single‑cycle.
- ADC conversion requires multiple cycles (depending on ADC architecture, assumed 8 cycles here).
- If multi‑cycle accumulation is needed, the accumulator updates after each ADC completion.
- Once all computation finishes, hardware sets `STATUS.DONE=1` and may optionally trigger an interrupt.


---

## 8. 性能监控计数器定义 / PMU Counter Definitions

| 计数器索引 / Counter Index | 名称 / Name | 描述 / Description |
|:---|:---|:---|
| `0` | `cycle_cnt` | 自上次复位以来的总周期数 |
| `1` | `comp_cnt` | 执行矩阵乘法的周期数 |
| `2` | `adc_wait_cnt` | 等待 ADC 转换的周期数 |
| `3` | `sensor_wait_cnt` | 等待传感器数据的周期数 |
| `4` | `wb_stall_cnt` | Wishbone 总线访问阻塞周期数 |


---

## 9. 附录：信号命名规范 / Appendix: Signal Naming Convention

- **后缀 `_i`**：输入信号 / Input signal
- **后缀 `_o`**：输出信号 / Output signal
- **后缀 `_n`**：低有效信号 / Active‑low signal
- **前缀 `wb_`**：Wishbone 总线信号 / Wishbone bus signal
- **前缀 `sen_`**：传感器接口信号 / Sensor interface signal

所有模块端口均采用此规范，以保持代码可读性与一致性。

All module ports adhere to this convention to maintain code readability and consistency.