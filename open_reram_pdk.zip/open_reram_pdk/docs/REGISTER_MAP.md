# 寄存器映射手册 / Register Map Manual

## 鸣蛇 (Ming She) 芯片

**文档版本 / Document Revision**: 0.1.0  
**最后更新 / Last Updated**: 2026-04-23


---

## 1. 概述 / Overview

本文档定义鸣蛇芯片中所有软件可访问寄存器的地址映射、位域分配、访问权限及复位值。寄存器通过 Wishbone B4 总线接口访问，地址空间为 32 位字对齐。

This document defines the address mapping, bit‑field allocation, access permissions, and reset values of all software‑accessible registers in the Ming She chip. Registers are accessed via the Wishbone B4 bus interface with 32‑bit word‑aligned address space.

### 1.1 地址空间 / Address Space

| 范围 / Range | 大小 / Size | 描述 / Description |
|:---|:---|:---|
| `0x0000_0000` – `0x0000_00FF` | 256 B | 控制与状态寄存器 / Control and Status Registers |
| `0x0000_0100` – `0x0000_01FF` | 256 B | 输入数据寄存器 / Input Data Registers |
| `0x0000_0200` – `0x0000_02FF` | 256 B | 输出数据寄存器 / Output Data Registers |
| `0x0000_0300` – `0x0000_03FF` | 256 B | 性能监控寄存器 / PMU Registers |

### 1.2 寄存器访问类型 / Register Access Types

| 缩写 / Abbreviation | 含义 / Meaning | 描述 / Description |
|:---|:---|:---|
| `RW` | 读/写 / Read/Write | 软件可读写 / Software may read and write |
| `RO` | 只读 / Read Only | 软件只读，硬件更新 / Read only by software, updated by hardware |
| `WO` | 只写 / Write Only | 软件只写，读返回 0 / Write only by software, reads return 0 |
| `RW1C` | 读/写 1 清零 / Read/Write 1 to Clear | 写 1 清零指定位，写 0 无效 / Write 1 clears the bit, write 0 has no effect |
| `RW1S` | 读/写 1 置位 / Read/Write 1 to Set | 写 1 置位，写 0 无效 / Write 1 sets the bit, write 0 has no effect |
| `RC` | 读清零 / Read Clear | 读操作后硬件自动清零 / Cleared by hardware after read |


---

## 2. 寄存器列表 / Register Summary

| 偏移 / Offset | 名称 / Name | 类型 / Type | 复位值 / Reset | 描述 / Description |
|:---|:---|:---|:---|:---|
| `0x00` | `CTRL` | RW | `0x0000_0000` | 控制寄存器 / Control Register |
| `0x04` | `STATUS` | RO | `0x0000_0000` | 状态寄存器 / Status Register |
| `0x08` | `WEIGHT_CFG` | RW | `0x0000_0000` | 权重配置寄存器 / Weight Configuration |
| `0x0C` | `INPUT_CFG` | RW | `0x0000_0000` | 输入配置寄存器 / Input Configuration |
| `0x10` | `INPUT_CH0` | RW | `0x0000_0000` | 输入通道 0 数据 / Input Channel 0 Data |
| `0x14` | `INPUT_CH1` | RW | `0x0000_0000` | 输入通道 1 数据 / Input Channel 1 Data |
| `0x18` | `INPUT_CH2` | RW | `0x0000_0000` | 输入通道 2 数据 / Input Channel 2 Data |
| `0x1C` | `INPUT_CH3` | RW | `0x0000_0000` | 输入通道 3 数据 / Input Channel 3 Data |
| `0x20` | `INPUT_CH4` | RW | `0x0000_0000` | 输入通道 4 数据 / Input Channel 4 Data |
| `0x24` | `INPUT_CH5` | RW | `0x0000_0000` | 输入通道 5 数据 / Input Channel 5 Data |
| `0x28` | `INPUT_CH6` | RW | `0x0000_0000` | 输入通道 6 数据 / Input Channel 6 Data |
| `0x2C` | `INPUT_CH7` | RW | `0x0000_0000` | 输入通道 7 数据 / Input Channel 7 Data |
| `0x30` | `OUTPUT_CH0` | RO | `0x0000_0000` | 输出通道 0 结果 / Output Channel 0 Result |
| `0x34` | `OUTPUT_CH1` | RO | `0x0000_0000` | 输出通道 1 结果 / Output Channel 1 Result |
| `0x38` | `OUTPUT_CH2` | RO | `0x0000_0000` | 输出通道 2 结果 / Output Channel 2 Result |
| `0x3C` | `OUTPUT_CH3` | RO | `0x0000_0000` | 输出通道 3 结果 / Output Channel 3 Result |
| `0x40` | `OUTPUT_CH4` | RO | `0x0000_0000` | 输出通道 4 结果 / Output Channel 4 Result |
| `0x44` | `OUTPUT_CH5` | RO | `0x0000_0000` | 输出通道 5 结果 / Output Channel 5 Result |
| `0x48` | `OUTPUT_CH6` | RO | `0x0000_0000` | 输出通道 6 结果 / Output Channel 6 Result |
| `0x4C` | `OUTPUT_CH7` | RO | `0x0000_0000` | 输出通道 7 结果 / Output Channel 7 Result |
| `0x50` | `PMU_CTRL` | RW | `0x0000_0000` | PMU 控制寄存器 / PMU Control |
| `0x54` | `PMU_VALUE` | RO | `0x0000_0000` | PMU 计数值寄存器 / PMU Counter Value |
| `0x58` | `PMU_STATUS` | RO | `0x0000_0000` | PMU 状态寄存器 / PMU Status |
| `0x5C` | `VERSION` | RO | `0x2026_0401` | 硬件版本号 / Hardware Version |
| `0x60` | `INT_EN` | RW | `0x0000_0000` | 中断使能寄存器 / Interrupt Enable |
| `0x64` | `INT_STATUS` | RW1C | `0x0000_0000` | 中断状态寄存器 / Interrupt Status |
| `0x68` | `SCRATCH` | RW | `0x0000_0000` | 软件临时寄存器 / Scratch Register |


---

## 3. 寄存器详细描述 / Detailed Register Descriptions

### 3.1 `CTRL` —— 控制寄存器 (偏移 `0x00`)

| 位 / Bits | 名称 / Name | 类型 / Type | 复位 / Reset | 描述 / Description |
|:---|:---|:---|:---|:---|
| 0 | `START` | RW1S | 0 | 写 1 启动推理，硬件在推理开始时自动清零 / Write 1 to start inference, cleared by hardware when inference begins |
| 1 | `ABORT` | RW1S | 0 | 写 1 中止当前推理，硬件自动清零 / Write 1 to abort current inference, self‑clearing |
| 3:2 | `PRECISION` | RW | 2'b00 | 精度模式：00=INT4, 01=INT8, 10=保留, 11=保留 / Precision mode: 00=INT4, 01=INT8, 10=Reserved, 11=Reserved |
| 4 | `SW_RST` | RW1S | 0 | 写 1 触发软件复位，硬件自动清零 / Write 1 triggers software reset, self‑clearing |
| 7:5 | `CLK_DIV` | RW | 3'b000 | 传感器时钟分频系数：000=不分频, 001=2分频, ..., 111=8分频 / Sensor clock divider: 000=bypass, 001=div2, ..., 111=div8 |
| 31:8 | — | — | 0 | 保留 / Reserved |

### 3.2 `STATUS` —— 状态寄存器 (偏移 `0x04`)

| 位 / Bits | 名称 / Name | 类型 / Type | 复位 / Reset | 描述 / Description |
|:---|:---|:---|:---|:---|
| 0 | `BUSY` | RO | 0 | 推理忙标志：1=正在执行推理 / Inference busy flag: 1=inference in progress |
| 1 | `DONE` | RO | 0 | 推理完成标志：1=推理已完成。该位在 `START` 写 1 或读取 `OUTPUT_CH0` 时自动清零 / Inference done flag: 1=inference completed. Cleared when `START` is written or `OUTPUT_CH0` is read |
| 2 | `ERR` | RO | 0 | 错误标志：1=发生错误（如无效配置）/ Error flag: 1=error occurred (e.g., invalid configuration) |
| 3 | `WEIGHT_RDY` | RO | 0 | 权重已加载标志：1=权重阵列已编程完成 / Weight ready flag: 1=weight array programmed |
| 7:4 | `FSM_STATE` | RO | 4'h0 | 当前顶层状态机状态编码（见架构文档）/ Current FSM state encoding (see Architecture document) |
| 15:8 | `ERR_CODE` | RO | 8'h00 | 错误代码（当 `ERR=1` 时有效）/ Error code (valid when `ERR=1`) |
| 31:16 | — | — | 0 | 保留 / Reserved |

### 3.3 `WEIGHT_CFG` —— 权重配置寄存器 (偏移 `0x08`)

通过此寄存器逐单元编程 ReRAM 阵列权重。写入后硬件自动生成编程脉冲序列。

Each write to this register programs one cell of the ReRAM array. Hardware automatically generates the programming pulse sequence.

| 位 / Bits | 名称 / Name | 类型 / Type | 复位 / Reset | 描述 / Description |
|:---|:---|:---|:---|:---|
| 3:0 | `ROW` | RW | 4'h0 | 目标行地址 (0–15) / Target row address (0–15) |
| 7:4 | `COL` | RW | 4'h0 | 目标列地址 (0–15) / Target column address (0–15) |
| 15:8 | `WEIGHT` | RW | 8'h00 | 权重值 (INT8 格式，有符号) / Weight value (INT8 format, signed) |
| 16 | `WR_EN` | RW1S | 0 | 写 1 触发编程操作，硬件自动清零 / Write 1 to trigger programming, self‑clearing |
| 31:17 | — | — | 0 | 保留 / Reserved |

### 3.4 `INPUT_CFG` —— 输入配置寄存器 (偏移 `0x0C`)

| 位 / Bits | 名称 / Name | 类型 / Type | 复位 / Reset | 描述 / Description |
|:---|:---|:---|:---|:---|
| 2:0 | `CH_SEL` | RW | 3'b000 | 当前配置的输入通道选择 (0–7) / Currently selected input channel (0–7) |
| 3 | `SENSOR_MODE` | RW | 1'b0 | 数据源选择：0=寄存器输入 (`INPUT_CH*`)，1=传感器接口 / Data source: 0=register input, 1=sensor interface |
| 5:4 | `SENSOR_TYPE` | RW | 2'b00 | 传感器协议类型：00=PDM, 01=I2S, 10=并行 ADC, 11=保留 / Sensor protocol: 00=PDM, 01=I2S, 10=Parallel ADC, 11=Reserved |
| 6 | `CHAIN_MODE` | RW | 1'b0 | 链式模式使能：1=多通道自动轮询 / Chain mode enable: 1=auto‑scan multiple channels |
| 31:7 | — | — | 0 | 保留 / Reserved |

### 3.5 `INPUT_CH0` – `INPUT_CH7` —— 输入通道数据寄存器 (偏移 `0x10` – `0x2C`)

当 `SENSOR_MODE=0` 时，这些寄存器提供输入向量数据。

When `SENSOR_MODE=0`, these registers provide the input vector data.

| 位 / Bits | 名称 / Name | 类型 / Type | 复位 / Reset | 描述 / Description |
|:---|:---|:---|:---|:---|
| 7:0 | `DATA` | RW | 8'h00 | 输入数据 (INT8/INT4 格式，精度由 `CTRL.PRECISION` 决定) / Input data (INT8/INT4 format, precision determined by `CTRL.PRECISION`) |
| 31:8 | — | — | 0 | 保留 / Reserved |

### 3.6 `OUTPUT_CH0` – `OUTPUT_CH7` —— 输出结果寄存器 (偏移 `0x30` – `0x4C`)

推理完成后，结果存储于这些只读寄存器。读取 `OUTPUT_CH0` 会清除 `STATUS.DONE` 标志。

After inference completes, results are stored in these read‑only registers. Reading `OUTPUT_CH0` clears the `STATUS.DONE` flag.

| 位 / Bits | 名称 / Name | 类型 / Type | 复位 / Reset | 描述 / Description |
|:---|:---|:---|:---|:---|
| 15:0 | `RESULT` | RO | 16'h0000 | 推理结果 (16 位有符号数) / Inference result (16‑bit signed) |
| 31:16 | — | — | 0 | 保留 / Reserved |

### 3.7 `PMU_CTRL` —— 性能监控控制寄存器 (偏移 `0x50`)

| 位 / Bits | 名称 / Name | 类型 / Type | 复位 / Reset | 描述 / Description |
|:---|:---|:---|:---|:---|
| 3:0 | `SEL` | RW | 4'h0 | 计数器选择索引 (0–4，见架构文档 PMU 定义) / Counter selection index (0–4, see PMU definitions in Architecture document) |
| 4 | `CAPTURE` | RW1S | 0 | 写 1 捕获当前计数值到 `PMU_VALUE` / Write 1 to capture current counter value to `PMU_VALUE` |
| 5 | `CLEAR` | RW1S | 0 | 写 1 清零所选计数器 / Write 1 to clear the selected counter |
| 31:6 | — | — | 0 | 保留 / Reserved |

### 3.8 `PMU_VALUE` —— PMU 计数值寄存器 (偏移 `0x54`)

| 位 / Bits | 名称 / Name | 类型 / Type | 复位 / Reset | 描述 / Description |
|:---|:---|:---|:---|:---|
| 31:0 | `VALUE` | RO | 32'h0 | 所选计数器的当前值 / Current value of the selected counter |

### 3.9 `PMU_STATUS` —— PMU 状态寄存器 (偏移 `0x58`)

| 位 / Bits | 名称 / Name | 类型 / Type | 复位 / Reset | 描述 / Description |
|:---|:---|:---|:---|:---|
| 0 | `OVERFLOW0` | RO | 0 | 计数器 0 溢出标志 / Counter 0 overflow flag |
| 1 | `OVERFLOW1` | RO | 0 | 计数器 1 溢出标志 / Counter 1 overflow flag |
| 2 | `OVERFLOW2` | RO | 0 | 计数器 2 溢出标志 / Counter 2 overflow flag |
| 3 | `OVERFLOW3` | RO | 0 | 计数器 3 溢出标志 / Counter 3 overflow flag |
| 4 | `OVERFLOW4` | RO | 0 | 计数器 4 溢出标志 / Counter 4 overflow flag |
| 31:5 | — | — | 0 | 保留 / Reserved |

### 3.10 `VERSION` —— 版本寄存器 (偏移 `0x5C`)

| 位 / Bits | 名称 / Name | 类型 / Type | 复位 / Reset | 描述 / Description |
|:---|:---|:---|:---|:---|
| 7:0 | `PATCH` | RO | 8'h01 | 修订版本号 / Patch version |
| 15:8 | `MINOR` | RO | 8'h04 | 次版本号 / Minor version |
| 23:16 | `MAJOR` | RO | 8'h26 | 主版本号 (2026) / Major version (2026) |
| 31:24 | `ID` | RO | 8'h4D | 芯片标识码 ('M' = Ming She) / Chip identifier ('M' = Ming She) |

复位值为 `0x4D_26_04_01`，表示鸣蛇芯片版本 v2026.04.01。

Reset value `0x4D_26_04_01` indicates Ming She chip version v2026.04.01.

### 3.11 `INT_EN` —— 中断使能寄存器 (偏移 `0x60`)

| 位 / Bits | 名称 / Name | 类型 / Type | 复位 / Reset | 描述 / Description |
|:---|:---|:---|:---|:---|
| 0 | `DONE_IE` | RW | 0 | 推理完成中断使能 / Inference done interrupt enable |
| 1 | `ERR_IE` | RW | 0 | 错误中断使能 / Error interrupt enable |
| 31:2 | — | — | 0 | 保留 / Reserved |

### 3.12 `INT_STATUS` —— 中断状态寄存器 (偏移 `0x64`)

写 1 清零对应位。

Write 1 clears the corresponding bit.

| 位 / Bits | 名称 / Name | 类型 / Type | 复位 / Reset | 描述 / Description |
|:---|:---|:---|:---|:---|
| 0 | `DONE_IF` | RW1C | 0 | 推理完成中断标志 / Inference done interrupt flag |
| 1 | `ERR_IF` | RW1C | 0 | 错误中断标志 / Error interrupt flag |
| 31:2 | — | — | 0 | 保留 / Reserved |

### 3.13 `SCRATCH` —— 临时寄存器 (偏移 `0x68`)

通用读写寄存器，供软件存储临时数据。

General‑purpose read/write register for software scratch storage.

| 位 / Bits | 名称 / Name | 类型 / Type | 复位 / Reset | 描述 / Description |
|:---|:---|:---|:---|:---|
| 31:0 | `DATA` | RW | 32'h0 | 软件自定义数据 / Software‑defined data |


---

## 4. 错误代码定义 / Error Code Definitions

当 `STATUS.ERR=1` 时，`STATUS.ERR_CODE` 指示具体错误原因。

When `STATUS.ERR=1`, `STATUS.ERR_CODE` indicates the specific error cause.

| 代码 / Code | 名称 / Name | 描述 / Description |
|:---|:---|:---|
| `0x01` | `ERR_INVALID_PREC` | 无效的精度模式配置 / Invalid precision mode configuration |
| `0x02` | `ERR_WEIGHT_BUSY` | 权重编程未完成时尝试启动推理 / Attempted to start inference while weight programming in progress |
| `0x03` | `ERR_SENSOR_TIMEOUT` | 传感器数据等待超时 / Sensor data wait timeout |
| `0x04` | `ERR_ADC_TIMEOUT` | ADC 转换超时 / ADC conversion timeout |
| `0x10` | `ERR_WB_ADDR` | Wishbone 访问地址越界 / Wishbone address out of bounds |
| `0xFF` | `ERR_UNKNOWN` | 未知错误 / Unknown error |


---

## 5. 编程示例 / Programming Examples

### 5.1 权重加载流程 / Weight Loading Sequence

1. 检查 `STATUS.BUSY`，等待空闲 / Check `STATUS.BUSY`, wait for idle.
2. 对于每个需编程的单元 (row, col) / For each cell to program (row, col):
   - 写入 `WEIGHT_CFG`，设置 `ROW`, `COL`, `WEIGHT`, `WR_EN=1` / Write `WEIGHT_CFG` with `ROW`, `COL`, `WEIGHT`, `WR_EN=1`.
   - 轮询 `WEIGHT_CFG.WR_EN` 直至硬件清零 / Poll `WEIGHT_CFG.WR_EN` until cleared by hardware.
3. 全部权重编程完成后，`STATUS.WEIGHT_RDY` 自动置 1 / After all weights are programmed, `STATUS.WEIGHT_RDY` is automatically set.

### 5.2 寄存器输入模式推理 / Register Input Mode Inference

1. 配置 `INPUT_CFG.SENSOR_MODE=0` / Configure `INPUT_CFG.SENSOR_MODE=0`.
2. 写入 8 个输入通道数据至 `INPUT_CH0` – `INPUT_CH7` / Write input data to `INPUT_CH0` – `INPUT_CH7`.
3. 写 `CTRL.START=1` / Write `CTRL.START=1`.
4. 轮询 `STATUS.DONE` 或等待中断 / Poll `STATUS.DONE` or wait for interrupt.
5. 从 `OUTPUT_CH0` – `OUTPUT_CH7` 读取结果 / Read results from `OUTPUT_CH0` – `OUTPUT_CH7`.

### 5.3 传感器流式模式推理 / Sensor Streaming Mode Inference

1. 配置 `INPUT_CFG.SENSOR_MODE=1`，选择 `SENSOR_TYPE` / Configure `INPUT_CFG.SENSOR_MODE=1`, select `SENSOR_TYPE`.
2. 写 `CTRL.START=1` / Write `CTRL.START=1`.
3. 芯片自动请求传感器数据，完成推理后置 `STATUS.DONE` / Chip automatically requests sensor data and sets `STATUS.DONE` upon completion.
4. 读取输出结果 / Read output results.


---

## 6. 寄存器复位值汇总 / Reset Value Summary

| 寄存器 / Register | 复位值 / Reset Value |
|:---|:---|
| `CTRL` | `0x0000_0000` |
| `STATUS` | `0x0000_0000` |
| `WEIGHT_CFG` | `0x0000_0000` |
| `INPUT_CFG` | `0x0000_0000` |
| `INPUT_CH[0:7]` | `0x0000_0000` |
| `OUTPUT_CH[0:7]` | `0x0000_0000` |
| `PMU_CTRL` | `0x0000_0000` |
| `PMU_VALUE` | `0x0000_0000` |
| `PMU_STATUS` | `0x0000_0000` |
| `VERSION` | `0x4D26_0401` |
| `INT_EN` | `0x0000_0000` |
| `INT_STATUS` | `0x0000_0000` |
| `SCRATCH` | `0x0000_0000` |


---

## 7. 声明 / Disclaimer

本寄存器映射手册为理论设计文档，所定义寄存器行为与位域分配均未经过实际硅验证。实际芯片的寄存器实现可能与本手册存在差异。

This register map manual is a theoretical design document. The described register behavior and bit‑field assignments have not been verified in silicon. Actual chip implementations may differ from this manual.

---