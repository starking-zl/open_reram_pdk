module NAND2_X1 (A, B, Y);
  input A, B;
  output Y;
  assign Y = ~(A & B);
endmodule
module INV_X1 (A, Y);
  input A;
  output Y;
  assign Y = ~A;
endmodule
