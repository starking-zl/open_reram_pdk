module reram_8x8 (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         cfg_we,
    input  wire [5:0]   cfg_addr,
    input  wire         cfg_data,
    input  wire [7:0]   vin,
    output wire [2:0]   dout,
    output wire         done
);
    reg [7:0] weight [0:7][0:7];
    integer i, j;
    always @(posedge clk) begin
        if (!rst_n) begin
            for (i=0; i<8; i=i+1)
                for (j=0; j<8; j=j+1)
                    weight[i][j] <= 8'b0;
        end else if (cfg_we) begin
            weight[cfg_addr[5:3]][cfg_addr[2:0]] <= cfg_data;
        end
    end
    wire [11:0] sum;
    assign sum = weight[0][0] * vin[0] + weight[0][1] * vin[1];
    assign dout = sum[11:9];
    assign done = 1'b1;
endmodule
