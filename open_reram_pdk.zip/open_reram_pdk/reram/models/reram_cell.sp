* 简化的 ReRAM 行为级 SPICE 模型
.subckt reram_cell TE BE PARAMS: Roff=1e6 Ron=1e4 Vset=1.2 Vreset=-1.0
.param state=0
Rmem TE BE {state==1 ? Ron : Roff}
.ends
